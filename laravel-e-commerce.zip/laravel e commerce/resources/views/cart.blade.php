
@extends('layouts.format')

@section('cart')
  active
@endsection

@section('stuff')


<center>
<h1>Cart</h1>
<hr></hr>

@if($errors->any())
    @foreach($errors->all() as $err)
      <p style="color:red">{{$err}}</p>
    @endforeach
  @endif
@if(Session::has('cart') && !empty(Session::get('cart')))
<table border="1" style="text-align:center"; >
  <tr>
    <th>Serial No</th> 
    <th>Product</th> 
    <th>Quantity</th>
    <th>Unit Price</th>
    <th>Total Price</th>
    <th>Options</th>
  </tr>

  <?php $count=1; $total=0;  ?>

    @foreach (Session::get('cart') as $product_id=>$quantity)
      @foreach($products as $key => $product)
        @if($product->pId==$product_id)
        <form action="{{Route('cart.updateQuantity')}}" method="post">
          {{csrf_field()}}
          <tr>
            <td>{{$count}} </td>
            <td>{{$product->name}}</td>
            <input type="text" name="id" value="{{$product_id}}" hidden="hidden">
            <td width="100px" height="32px;"><input type="text" name="quantity" value="{{$quantity}}" style=" text-align: center; height:23px; width:70px;"></input></td>
            <td>{{$product->price}}</td>
            <td>{{$product->price*$quantity}}</td>
            <td><input type="submit" class="btn-success" value="Update"></input> | <button class="btn-danger"><a style="color:white;" href="{{Route('cart.remove',[$product->pId])}}" onclick="alert('remove?')">Remove</a></button></td>
          </tr>
        </form>

        <?php $total+=$product->price*$quantity; ?>
        @endif
      @endforeach
      <?php $count++;?>
    @endforeach

</table>
  <p>Grand Total:{{$total}}</p>

  <form action="{{Route('order.place')}}" method="post">
    {{csrf_field()}}
    <input type="text" name="price" value="{{$total}}" hidden="hidden"></input>
    <label>Phone Number</label><br>
    <input type="text" name="phone" value="{{ $orders->phone or '' }}"</input><br>
    <label>Shipping Address</label><br>
    <textarea name="address" cols="50" rows="5">{{ $orders->address or '' }} </textarea><br>
    <input type="submit" class="btn-success" value="Place Order" onclick="alert('confirm?');"></input>
  </form>
  

  @else
    <p>The Cart is Empty!</p>
    
  @endif

  @if(Session::has('msg'))
    <h2>{{Session::get('msg')}}</h2>
  @endif

</center>
@endsection
