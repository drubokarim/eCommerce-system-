<!DOCTYPE html>
<html>
<head>
	<title>E Commerce</title>
  <link href="{{ asset('/css/bootstrap.css') }}" rel="stylesheet"> 
  <link href="{{ asset('/css/jquery-ui.css') }}" rel="stylesheet"> 
    <script src="{{ asset('/js/jquery.js') }}"></script>
	<script src="{{ asset('/js/jquery-ui.js') }}"></script>

  <script>
  $( function() {
    $( "#datepicker" ).datepicker({ yearRange: "-100:+0", changeMonth: true,
            changeYear: true, }).datepicker( "option", "dateFormat", "yy-mm-dd" );
  } );
  </script>

  <style type="text/css">
  footer{
   background-color: #222222;
  margin-top: 20px;
    height: 32px;
    text-align: center;
    color: #CCC;
}

footer p {
    padding: 8.5px;
    margin: 0px;
    line-height: 100%;
}

footer p span{
  font-weight: bold;
}

.ui-datepicker select.ui-datepicker-month, .ui-datepicker select.ui-datepicker-year {
    color:black;
}

</style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header"  style="padding-left:15px; padding-right:20px">
      <a class="navbar-brand" href="/">E-commerce</a>
    </div>
    <ul class="nav navbar-nav pull-right">
      <li class="@yield('home')"><a href="/">Home</a></li>
      <li class="@yield('products')"><a href="{{route('products.index')}}">Products</a></li>
      @if(Session::has('loggedUser'))
        @if(Session::get('loggedUser')->type=='Admin')
          <li class="@yield('admin.home')"><a href="{{route('admin.home')}}">Profile Home</a></li>
        @else
          <li class="@yield('cart')"><a href="{{route('cart.index')}}">Cart</a></li>
          <li class="@yield('user.home')"><a href="{{route('user.home')}}">Profile Home</a></li>
        @endif
        <li><a href="{{route('logout.index')}}">Logout</a></li>
      @else
        <li class="@yield('cart')"><a href="{{route('cart.index')}}">Cart</a></li>
        <li class="@yield('login')"><a href="{{route('login.index')}}">Login</a></li>
        <li class="@yield('register')"><a href="{{route('register.index')}}">Register</a></li>
      @endif
    </ul>
  </div>
</nav>

@yield('stuff');



  <footer>
      <p>Developed By <span>Mushfiq, Dhrubo, Mithun and Mehedi</span></p>

  </footer>

</body>
</html>