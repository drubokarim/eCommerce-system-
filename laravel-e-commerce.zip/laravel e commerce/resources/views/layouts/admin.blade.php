<!DOCTYPE html>
<html>
<head>
	<title>@yield('title') - User Manager</title>
  <link href="{{ asset('/css/bootstrap.css') }}" rel="stylesheet"> 
	<link href="{{ asset('/js/jquery.js') }}" rel="stylesheet"> 
	<style type="text/css">

  footer{
   background-color: #222222;
   margin-top: 20px;
    height: 35px;
    text-align: center;
    color: #CCC;
}

footer p {
    padding: 10.5px;
    margin: 0px;
    line-height: 100%;
}

footer p span{
  font-weight: bold;
}

</style>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header"  style="padding-left:15px; padding-right:20px">
      <a class="navbar-brand" href="#">Ecommerce</a>
    </div>
    <ul class="nav navbar-nav pull-right">
      <li><a href="/">Home</a></li>
      <li><a href="{{route('products.index')}}">Products</a></li>
      
      @if(Session::has('loggedUser'))
      	@if(Session::get('loggedUser')->type=='Admin')
      		<li class="@yield('admin.home')"><a href="{{route('admin.home')}}">Profile Home</a></li>
      	@else
      		<li class="@yield('admin.home')"><a href="{{route('user.home')}}">Profile Home</a></li>
      	@endif
        <li><a href="{{route('logout.index')}}">Logout</a></li>
      @else
        <li><a href="{{route('login.index')}}">Login</a></li>
        <li><a href="{{route('register.index')}}">Register</a></li>
      @endif
    </ul>
  </div>
</nav>
	<table border="0" width="100%" >
		<tr>
			<td width="100"></td>
			<td align="center">
				<h1>User Manager</h1>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td align="center">
				<hr/>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td align="center">
				<a href="{{Route('admin.home')}}">Home</a> |
				<a href="{{Route('admin.users')}}">Users</a> |
				<a href="{{Route('admin.settings')}}">Settings</a> |
				<a href="{{Route('categories.settings')}}">Categories</a> |
				<a href="{{Route('products.settings')}}">Products</a> |
				<a href="{{Route('orders.index')}}">Orders</a> |
				<a href="{{Route('admin.report')}}">Report</a> |
				<a href="{{Route('logout.index')}}">Logout</a>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td>
				<br/>
				<center>
					@yield('contents')
				</center>
			</td>
			<td width="100"></td>
		</tr>
	</table>


  <footer>
      <p>Developed By <span>Mushfiq, Dhrubo, Mithun and Mehedi</span></p>
 
  </footer>

</body>
</html>