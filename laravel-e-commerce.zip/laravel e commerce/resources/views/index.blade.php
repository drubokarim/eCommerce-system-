
@extends('layouts.format')


@section('home')
  active
@endsection


@section('stuff')
<div style="min-height:485px;">
	<h1 style="padding-top: 220px; text-align:center;">Welcome to E-Commerce Site. Browse through the topbar menus for shopping.</h1>
</div>
@endsection