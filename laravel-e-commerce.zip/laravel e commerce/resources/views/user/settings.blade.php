@extends('layouts.user')


@section('title')
Settings
@endsection

@section('contents')
<center>
<h3>Change Password</h3>
<form method="post">
{{csrf_field()}}
		<table>
			<tr>
				<td>USERNAME: </td>
				<td>{{$uname}}</td>
			</tr>
			<tr>
				<td>OLD PASSWORD: </td>
				<td><input type="password" name="oldPass"></td>
			</tr>
			<tr>
				<td>NEW PASSWORD: </td>
				<td><input type="password" name="newPass"></td>
			</tr>
			<tr>
				<td>RE-TYPE PASSWORD: </td>
				<td><input type="password" name="conPass"></td>
			</tr>
			<tr>
				<td colspan="2">
					<br/>
					<center>
						<a href="{{ url()->previous() }}">Back</a> | 
						<input type="submit" value="Update">
					</center>
				</td>
			</tr>
		</table>
	</form>
	<br/>
	<br/>
	<label>@if($errors->any())
				@foreach($errors->all() as $err)
					{{$err}}
				@endforeach
			@endif

		  @if(Session::has('msg'))
		    <h2>{{Session::get('msg')}}</h2>
		  @endif

			  </label>
</center>
@endsection