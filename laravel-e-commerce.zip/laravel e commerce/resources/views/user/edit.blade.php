@extends('layouts.user')

@section('title')
	Edit
@endsection

@section('contents')
	<center>
	<h3>Edit User Information</h3>
	<form method="post">
	{{csrf_field()}}
			<table>
				<tr>
					<td>FULL NAME: </td>
					<td><input type="text" value="{{$fullName}}" name="fullName"></td>
				</tr>
				<tr>
					<td>EMAIL: </td>
					<td><input type="text" value="{{$email}}" name="email"></td>
				</tr>
				<tr>
					<td colspan="2">
						<br/>
						<center>
							<a href="{{ url()->previous() }}">Back</a> | 
							<input type="submit" value="Update">
						</center>
					</td>
				</tr>
			</table>
		</form>
		<br/>
		<br/>
		<label>@if($errors->any())
				@foreach($errors->all() as $err)
					{{$err}}
				@endforeach
			@endif

			 @if(Session::has('msg'))
			    <h2>{{Session::get('msg')}}</h2>
			  @endif
			</label>
	</center>
@endsection