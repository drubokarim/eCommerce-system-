@extends('layouts.user')

@section('title')
Orders
@endsection

@section('contents')
				<h3>My Orders List</h3>
					@if(Session::has('msg'))
				    	<h2 style="color:green; font-weight:bold;">{{Session::get('msg')}}</h2>
				    @endif
					<br/>
					<table border="1" style="text-align:center">
						<tr>
							<th>S.N.</th>
							<th>ORDER ID</th>
							<th>PRODUCT(S)</th>
							<th>TOTAL PRICE</th>
							<th>SHIPPING ADDRESS</th>
							<th>PHONE NUMBER</th>
							<th>ORDER DATE</th>
							<th>ORDER STATUS</th>
						</tr>
						<?php $count=1;?>
						@foreach($orders as $order)
						<tr>
							<td>{{$count}}</td>
							<td>{{$order->orderId}}</td>
							<?php $prods = json_decode($order->products,true);?>
							<td>
							<?php $count2=1;?>

								@foreach($prods as $prod)
							       @foreach($productsInfo as $p)
										
								        @if($prod['pId']==$p->pId)
								        	<p style="text-align:left; padding:0px 10px;"><span style="font-weight:bold">item {{$count2}}:</span> {{$prod['quantity']}} piece(s) {{$prod['pName']}}->{{$prod['pPrice']}} tk per piece</p>
								        @endif
								        
							       @endforeach
							       <?php $count2++; ?>
								@endforeach
							</td>
							<td>{{$order->price}}</td>
							<td>{{$order->address}}</td>
							<td>{{$order->phone}}</td>
							<td>{{$order->orderDate}}</td>
							<td style="color:#4caf50; font-weight:bold;">{{$order->status}}</td>
						</tr>
						<?php $count++; ?>
						@endforeach
						
						<!-- <tr>
							<td><a href="details.html">Sally</a></td>
							<td>sally</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr>
						<tr>
							<td><a href="details.html">James</a></td>
							<td>james</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr> -->
					</table>

					
				@endsection