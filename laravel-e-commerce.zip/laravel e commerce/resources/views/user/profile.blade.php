@extends('layouts.user')

@section('title')
	Profile
@endsection

@section('contents')
<center>
<h3>My Profile</h3>
<form method="post">
		<table>
			<tr>
				<td>FULL NAME: </td>
				<td>{{$fname}}</td>
			</tr>
			<tr>
				<td>EMAIL: </td>
				<td>{{$email}}</td>
			</tr>
			<tr>
				<td>USERNAME: </td>
				<td>{{$uname}}</td>
			</tr>
			<tr>
				<td>TYPE: </td>
				<td>{{$type}}</td>
			</tr>
			<tr>
				<td colspan="2">
					<br/>
					<center>
						<a href="{{ url()->previous() }}">Back</a> | 
						<a href="{{Route('user.edit')}}">Edit</a>
					</center>
				</td>
			</tr>
		</table>
	</form>
</center>
@endsection