
@extends('layouts.format')


@section('products')
  active
@endsection


<!-- 
<script type="text/javascript">
  $(function(){
    $('#addToCart').click(function(){
        $.ajax({
        	url: '/cart/'$('#id').html(),
        	
        	method: 'get',
        	/*data: {
        		id:$('#id').html();
        	},*/
        	success: function(respoonse){
        		alert(response);
        	} 

        });
    });
  })
</script> -->
@section('stuff')
<section class="body col-md-12">

	@foreach($categories as $key => $category)
	<div class="category pull-left col-md-12">
			<h1>{{$category->cName}}</h1>
			<div class="row">
			@foreach($products as $key => $product)
				@if($product->cName == $category->cName)
				  <div class="col-md-3">
				     <div class="col-md-12" style="border:2px solid gray; text-align:center" >
						<img src="{{$product->img}}" style="width:250px; height:auto ">
						<h2>{{$product->name}}</h2>
						<p>{{$product->description}}</p>
						<p><span style="font-weight:bold">Price: </span>{{$product->price}}/-</p>
						<a href="{{route('cart.add', [$product->pId])}}"><button>add to cart</button></a>
				     </div>
				  </div>
				 @endif
			@endforeach
			</div>
		</div>
		@endforeach
</section>
@endsection

@if(Session::has('msg'))
  <script>alert('Product Added To Cart')</script>
@endif
