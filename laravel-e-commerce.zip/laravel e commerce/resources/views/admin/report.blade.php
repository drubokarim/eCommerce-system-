@extends('layouts.admin')

@section('title')
Report
@endsection

@section('contents')
				<h3>User Statistics</h3>
					<table border="1">
						<tr>
							<th>USER TYPE</th>
							<th>TOTAL USER</th>
						</tr>
						<tr>
							<td>Admin</td>
							<td>{{$admin}}</td>
						</tr>
						<tr>
							<td>User</td>
							<td>{{$user}}</td>
						</tr>
					</table>
					<br/>

					<h3>Best Buyer</h3>
					<table border="1" style="text-align:center;">
						<tr>
							<th>CUSTOMER ID</th>
							<th>CUSTOMER NAME</th>
							<th>NUMBER OF BOUGHT PRODUCTS</th>
							<th>TOTAL SPENT</th>
						</tr>

								
						<tr>
							<td>{{$bestCustId}}</td>
							<td>{{$bestCustName}}</td>
							<td>{{$max}}</td>
							<td>{{$bestCustSpent}}</td>
						</tr>
					</table>

					<h3>User Activity</h3>
					<table border="1">
						<tr>
							<th>INACTIVE SINCE</th>
							<th>TOTAL USER</th>
							<th>DETAILS</th>
						</tr>
						<tr>
							<?php $cat1=$cat2=$cat3=$cat4=0;?>
								@foreach($inactivity as $id => $month)	
									@if($month>3 && $month<6)
										<?php $cat1++;?>
										
									@elseif($month>6 && $month<9)
										<?php $cat2++;?>

									@elseif($month>9 && $month<12)
										<?php $cat3++;?>
									
									@elseif($month>12)
										<?php $cat4++;?>
									
									@endif
								@endforeach
							</td>

							<td>3 - 6 Months</td>
							<td>{{$cat1}}</td>
							
							<td><a href="{{Route('report.details', [1])}}">Details</a></td>
						</tr>
						<tr>
							<td>6 - 9 Months</td>
							<td>{{$cat2}}</td>
							<td><a href="{{Route('report.details', [2])}}">Details</a></td>
						</tr>
						<tr>
							<td>9 - 12 Months</td>
							<td>{{$cat3}}</td>
							<td><a href="{{Route('report.details', [3])}}">Details</a></td>
						</tr>
						<tr>
							<td>More than 12 Months</td>
							<td>{{$cat4}}</td>
							<td><a href="{{Route('report.details', [4])}}">Details</a></td>
						</tr>
					</table>

					
				</center>
			@endsection