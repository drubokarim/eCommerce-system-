@extends('layouts.admin')

@section('title')
Home
@endsection

@section('contents')
				<h3>User List</h3>
					
					<br/>
					<table border="1">
						<tr>
							<th>FULL NAME</th>
							<th>USERNAME</th>
							<th>TYPE</th>
							<th>OPTION</th>
						</tr>
						@foreach($users as $usr)
						<tr>
							<td><a href="details.html">{{$usr->fullName}}</a></td>
							<td>{{$usr->username}}</td>
							<td>{{$usr->type}}</td>
							<td><a href="{{Route('edit.index', [$usr->userId])}}">Edit</a> | <a href="{{Route('delete.index', [$usr->userId])}}">Delete</a></td>
						</tr>
						@endforeach

						@if(Session::has('msg'))
							<h2 style="color:red;">{{ Session::get('msg') }}</h2>
						@endif
						<!-- <tr>
							<td><a href="details.html">Sally</a></td>
							<td>sally</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr>
						<tr>
							<td><a href="details.html">James</a></td>
							<td>james</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr> -->
					</table>
				@endsection