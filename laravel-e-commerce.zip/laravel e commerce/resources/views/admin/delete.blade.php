@extends('layouts.admin')

@section('title')
Delete
@endsection

@section('contents')
				<h3>Delete User</h3>
				<form method="post">
				{{csrf_field()}}
						<table>
							<tr>
								<td>FULL NAME: </td>
								<td>{{$fullName}}</td>
							</tr>
							<tr>
								<td>EMAIL: </td>
								<td>{{$email}}</td>
							</tr>
							<tr>
								<td>USERNAME: </td>
								<td>{{$username}}</td>
							</tr>
							<tr>
								<td>TYPE: </td>
								<td>{{$type}}</td>
							</tr>
							<tr>
								<td>LAST LOGIN: </td>
								<td>{{$lastLogin}}</td>
							</tr>
							<tr>
								<td colspan="2">
									<br/>
									<center><strong>Are you sure to delete this user?</strong></center>
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<a href="users.html">Back</a> | 
										<input type="submit" value="Confirm">
									</center>
								</td>
							</tr>
						</table>
					</form>
					<br/>
					<br/>
					<label>Any message goes here</label>
			@endsection