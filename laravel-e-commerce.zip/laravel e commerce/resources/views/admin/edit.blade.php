@extends('layouts.admin')

@section('title')
Edit
@endsection

@section('contents')
				<h3>Edit User Information</h3>
				<form method="post">
				{{csrf_field()}}
						<table>
							<tr>
								<td>FULL NAME: </td>
								<td>{{$fullName}}</td>
							</tr>
							<tr>
								<td>USERNAME: </td>
								<td>{{$username}}</td>
							</tr>
							<tr>
								<td>TYPE: </td>
								<td>
									<select name="type">
										@if($type=='Admin')
											<option value="Admin">Admin</option>
											<option value="User">User</option>
										@else										
											<option value="User">User</option>
											<option value="Admin">Admin</option>
										@endif
									</select>
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<a href="{{ url()->previous() }}">Back</a> | 
										<input type="submit" value="Confirm">
									</center>
								</td>
							</tr>
						</table>
					</form>
					<br/>
					<br/>
					<label><!-- Any message goes here --></label>
				@endsection