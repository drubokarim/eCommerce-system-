@extends('layouts.admin')

@section('title')
Home
@endsection

@section('admin.home')
active
@endsection

@section('contents')
<h3>Admin Home</h3>
<p>Welcome <strong>{{$uname}}</strong></p>
<p>Your last login was on {{Session::get('lastlog')}} PM</p>

 @if(Session::has('msg'))
	<h2 style="color:green">{{Session::get('msg')}}</h2>
@endif
				
@endsection