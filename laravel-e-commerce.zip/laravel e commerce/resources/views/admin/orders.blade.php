@extends('layouts.admin')

@section('title')
Home
@endsection

@section('contents')
				<h3>Orders List</h3>
				@if(Session::has('msg'))
			 	   <h2 style="color:green;">{{Session::get('msg')}}</h2>
				@endif
					<br/>
					<table border="1" style="text-align:center">
						<tr>
							<th>ORDER ID</th>
							<th>PRODUCTS</th>
							<th>CUSTOMER ID</th>
							<th>CUSTOMER NAME</th>
							<th>TOTAL PRICE</th>
							<th>SHIPPING ADDRESS</th>
							<th>PHONE NUMBER</th>
							<th>ORDER DATE</th>
							<th>ORDER STATUS</th>
						</tr>
						<?php $count=1;?>
						@foreach($orders as $order)
						<tr>
							<td>{{$order->orderId}}</td>
							<?php $prods = json_decode($order->products,true);?>
							
								<?php $prods = json_decode($order->products,true); ?>
									<?php $count2=1;?>
								<td>@foreach ($prods as $prod)					
								<span style="font-weight:bold">item {{$count2}}:</span>  {{$prod['quantity']}} piece(s) {{$prod['pName']}}->{{$prod['pPrice']}} tk per piece 
								<br>
								<?php $count2++; ?>
								@endforeach
							
							<td>{{$order->customerId}}</td>
							<td>{{$order->fullName}}</td>
							<td>{{$order->price}}</td>
							<td>{{$order->address}}</td>
							<td>{{$order->phone}}</td>
							<td>{{$order->orderDate}}</td>
							<td>
								<form method="post">
								{{csrf_field()}}
									<select name="status">
										@if($order->status=='Processed')
											<option value="Processed">Processed</option>
											<option value="Pending">Pending</option>
											<option value="Delivered">Delivered</option>
										@elseif($order->status=='Delivered')
											<option value="Delivered">Delivered</option>
											<option value="Pending">Pending</option>
											<option value="Processed">Processed</option>
										@else
											<option value="Pending">Pending</option>
											<option value="Processed">Processed</option>
											<option value="Delivered">Delivered</option>
										@endif
									</select>					
									<input type="text" name="id" value="{{$order->orderId}}" hidden="hidden">
									<input type="submit" value="Update">
								</form>
							</td>
						</tr>
						<?php $count++; ?>
						@endforeach
						
						<!-- <tr>
							<td><a href="details.html">Sally</a></td>
							<td>sally</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr>
						<tr>
							<td><a href="details.html">James</a></td>
							<td>james</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr> -->
					</table>

					
				@endsection