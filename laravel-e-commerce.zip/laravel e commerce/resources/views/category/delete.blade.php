@extends('layouts.admin')

@section('title')
Home
@endsection

@section('contents')
<h3>Product Details</h3>
				
						<table>
							<tr>
								<td>CATEGORY NAME: </td>
								<td>
									
                                      {{$category->cName}}
									
								</td>
							</tr>
							
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<a href="{{Route('categories.settings')}}">Back</a>
									</center>
								</td>
							</tr>
						</table>
						<h4>Are you sure that you want to delete this category?</h4> 
						<form method="post"> 
							{{csrf_field()}} 
							<input type="hidden" name="categoryId" value="{{$category->id}}"> 
							<input type="submit" value="Confirm">
						
						 </form>
@endsection