@extends('layouts.admin')

@section('title')
Home
@endsection

@section('contents')

<h3>Edit Product Information</h3>
				<form method="post" enctype="multipart/form-data">
					{{csrf_field()}}
					<input type="hidden" name="categoryId" value="{{$category->id}}">
						<table>
							<tr>
								<td>CATEGORY NAME: </td>
								<td><input type="text" name="cname" value="{{$category->cName}}"></td>
							</tr>
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<a href="{{Route('categories.settings')}}">Back</a> | 
										<input type="submit" value="Update">
									</center>
								</td>
							</tr>
						</table>
					</form>
					<br/>
					<br/>
					<label>
					@if($errors->any())
		              @foreach($errors->all() as $err)
			            <p>{{$err}}</p>
		              @endforeach
	                @endif
					</label>				

					@endsection