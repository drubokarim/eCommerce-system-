@extends('layouts.admin')

@section('title')
Home
@endsection

@section('contents')

				<h3>Create New Category</h3>
				<form method="post" action="{{Route('categories.store')}}" enctype="multipart/form-data">
					{{csrf_field()}}
					
						<table>
							<tr>
								<td>CATEGORY NAME: </td>
								<td><input type="text" name="cname"></td>
							</tr>
							
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<input type="submit" value="Create">
									</center>
								</td>
							</tr>
						</table>
					</form>
					<br/>
					<br/>
					<label>
					@if($errors->any())
		              @foreach($errors->all() as $err)
			            <p>{{$err}}</p>
		              @endforeach
	                @endif
	                
					</label>
@endsection			