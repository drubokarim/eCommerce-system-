@extends('layouts.admin')

@section('title')
Home
@endsection

@section('contents')
				<h3>Product List</h3>
				<a href="{{Route('categories.add')}}">Add New Category</a>
				  @if(Session::has('msg'))
				    <h2 style="color:green">{{Session::get('msg')}}</h2>
				  @endif
				  <br>
					<br/>
					<table border="1">
						<tr>
							<th>ID</th>
							<th>NAME</th>
							<th>OPTION</th>
						</tr>
						@foreach($categories as $category)
						<tr>
							<td width="25px">{{$category->id}}</td>
							<td>{{$category->cName}}</td>
							<td><a href="{{Route('categories.edit', [$category->id])}}">Edit</a> | <a href="{{Route('categories.delete', [$category->id])}}">Delete</a></td>
						</tr>
						@endforeach
						
						<!-- <tr>
							<td><a href="details.html">Sally</a></td>
							<td>sally</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr>
						<tr>
							<td><a href="details.html">James</a></td>
							<td>james</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr> -->
					</table>
				@endsection