@extends('layouts.admin')

@section('title')
Home
@endsection

@section('contents')

<h3>Edit Product Information</h3>
				<form method="post" enctype="multipart/form-data">
					{{csrf_field()}}
					<input type="hidden" name="productId" value="{{$product->pId}}">
						<table>
							<tr>
								<td>PRODUCT NAME: </td>
								<td><input type="text" name="pname" value="{{$product->name}}"></td>
							</tr>
							<tr>
								<td>DESCRIPTION: </td>
								<td><input type="text" name="description" value="{{$product->description}}"></td>
							</tr>
							<tr>
								<td>PRICE: </td>
								<td><input type="text" name="price" value="{{$product->price}}"></td>
							</tr>
							<tr>
								<td>Category: </td>
								<td>
									<select name="category">
								   		<option value="{{$product->categoryId}}">{{$product->cName}}</option>	
										@foreach($categories as $cat)
											@if($cat->id!=$product->categoryId)
										   		<option value="{{$cat->id}}">{{$cat->cName}}</option>							
										   	@endif
										@endforeach
									</select>
								</td>
							</tr>
							<tr>
								<td>CURRENT IMAGE: </td>
								<td><img src="{{$product->img}}" style="width:180px; height:auto;"></td>
							</tr>
							<tr>
								<td>CHANGE IMAGE: </td>
								<td><input type="file" name="pic" value="{{$product->img}}"></td>
							</tr>
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<a href="{{Route('products.settings')}}">Back</a> | 
										<input type="submit" value="Update">
									</center>
								</td>
							</tr>
						</table>
					</form>
					<br/>
					<br/>
					<label>
					@if($errors->any())
		              @foreach($errors->all() as $err)
			            <p>{{$err}}</p>
		              @endforeach
	                @endif
					</label>				

					@endsection