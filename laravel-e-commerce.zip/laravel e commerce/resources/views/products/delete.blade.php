@extends('layouts.admin')

@section('title')
Home
@endsection

@section('contents')
<h3>Product Details</h3>
				
						<table>
							<tr>
								<td>PRODUCT NAME: </td>
								<td>
									
                                      {{$product->name}}
									
								</td>
							</tr>
							<tr>
								<td>DESCRIPTION: </td>
								<td>
                                    
                                      {{$product->description}}
									
								</td>
							</tr>
							<tr>
								<td>PRICE: </td>
								<td>
									  {{$product->price}}
									
								</td>
							</tr>
							<tr>
								<td>CATEGORY: </td>
								<td>
									 {{$product->cName}}
								</td>
							</tr>
							<tr>
								<td>PICTURE: </td>
								<td>
									<img src="{{$product->img}}" style="width:200px; height:auto;">
								</td>
							</tr>
							
							
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<a href="{{Route('products.settings')}}">Back</a>
									</center>
								</td>
							</tr>
						</table>
						<h4>Are you sure that you want to delete this product?</h4> 
						<form method="post"> 
							{{csrf_field()}} 
							<input type="hidden" name="productId" value="{{$product->pId}}"> 
							<input type="submit" value="Confirm">
						
						 </form>
@endsection