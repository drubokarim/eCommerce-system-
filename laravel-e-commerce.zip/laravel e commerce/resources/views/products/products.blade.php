@extends('layouts.admin')

@section('title')
Home
@endsection

@section('contents')
				<h3>Product List</h3>
				<a href="{{Route('products.add')}}">Add New Product</a>
				  @if(Session::has('msg'))
				    <h2 style="color:green">{{Session::get('msg')}}</h2>
				  @endif
				  <br>
					<br/>
					<table border="1">
						<tr>
							<th>ID</th>
							<th>IMAGE</th>
							<th>NAME</th>
							<th>DESCRIPTION</th>
							<th>PRICE</th>
							<th>CATEGORY</th>
							<th>OPTION</th>
						</tr>
						@foreach($products as $product)
						<tr>
							<td width="25px">{{$product->pId}}</td>
							<td><img src="{{$product->img}}" style="width:180px; padding:5px; height:auto;"></td>
							<td>{{$product->name}}</td>
							<td>{{$product->description}}</td>
							<td>{{$product->price}}</td>
							<td>{{$product->cName}}</td>
							<td><a href="{{Route('product.edit', [$product->pId])}}">Edit</a> | <a href="{{Route('product.delete', [$product->pId])}}">Delete</a></td>
						</tr>
						@endforeach
						
						<!-- <tr>
							<td><a href="details.html">Sally</a></td>
							<td>sally</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr>
						<tr>
							<td><a href="details.html">James</a></td>
							<td>james</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr> -->
					</table>
				@endsection