@extends('layouts.admin')

@section('title')
Home
@endsection

@section('contents')

				<h3>Create new product</h3>
				<form method="post" action="{{Route('products.store')}}" enctype="multipart/form-data">
					{{csrf_field()}}
					
						<table>
							<tr>
								<td>PRODUCT NAME: </td>
								<td><input type="text" name="pname"></td>
							</tr>
							<tr>
								<td>DESCRIPTION: </td>
								<td><input type="text" name="description" ></td>
							</tr>
							<tr>
								<td>PRICE: </td>
								<td><input type="text" name="price" ></td>
							</tr>
							<tr>
								<td>PRODUCT IMAGE: </td>
								<td><input type="file" name="pic"></td>
							</tr>

							<tr>
								<td>CATEGORY</td>
								<td>
									<select name="category">
										@foreach($categories as $cat)										   
										   	<option value="{{$cat->id}}">{{$cat->cName}}</option>									   
										@endforeach
									</select>
								</td>
							</tr>
							
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<input type="submit" value="Create">
									</center>
								</td>
							</tr>
						</table>
					</form>
					<label>
					@if($errors->any())
		              @foreach($errors->all() as $err)
			            <p>{{$err}}</p>
		              @endforeach
	                @endif
					</label>
@endsection			