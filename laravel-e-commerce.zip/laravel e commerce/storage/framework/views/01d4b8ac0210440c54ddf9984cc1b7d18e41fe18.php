<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
				<h3>Product List</h3>
				<a href="<?php echo e(Route('products.add')); ?>">Add New Product</a>
				  <?php if(Session::has('msg')): ?>
				    <h2 style="color:green"><?php echo e(Session::get('msg')); ?></h2>
				  <?php endif; ?>
				  <br>
					<br/>
					<table border="1">
						<tr>
							<th>ID</th>
							<th>IMAGE</th>
							<th>NAME</th>
							<th>DESCRIPTION</th>
							<th>PRICE</th>
							<th>CATEGORY</th>
							<th>OPTION</th>
						</tr>
						<?php foreach($products as $product): ?>
						<tr>
							<td width="25px"><?php echo e($product->pId); ?></td>
							<td><img src="<?php echo e($product->img); ?>" style="width:180px; padding:5px; height:auto;"></td>
							<td><?php echo e($product->name); ?></td>
							<td><?php echo e($product->description); ?></td>
							<td><?php echo e($product->price); ?></td>
							<td><?php echo e($product->cName); ?></td>
							<td><a href="<?php echo e(Route('product.edit', [$product->pId])); ?>">Edit</a> | <a href="<?php echo e(Route('product.delete', [$product->pId])); ?>">Delete</a></td>
						</tr>
						<?php endforeach; ?>
						
						<!-- <tr>
							<td><a href="details.html">Sally</a></td>
							<td>sally</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr>
						<tr>
							<td><a href="details.html">James</a></td>
							<td>james</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr> -->
					</table>
				<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>