<?php $__env->startSection('content'); ?>
				<h3>Products</h3>
					<table border="1">
						<tr>
							<th>PRODUCT NAME</th>
							<th>DESCRIPTION</th>
							<th>PRICE</th>
							<th>CATEGORY</th>
							<th>OPTION</th>
						</tr>
						<?php foreach($PRODUCTS as $products): ?>
						<tr>
							<td><a href="<?php echo e(route('product.show',[$products->pId])); ?>"><?php echo e($products->name); ?></a></td>
							<td><?php echo e($products->description); ?></td>
							<td><?php echo e($products->price); ?></td>
							<td><?php echo e($products->cName); ?></td>
							<td><a href="<?php echo e(route('product.show',[$products->pId])); ?>">Edit</a> | <a href="<?php echo e(route('product.delete',[$products->pId])); ?>">Delete</a></td>
						</tr>
						<?php endforeach; ?>
					</table>
<?php $__env->stopSection(); ?>					
				
<?php echo $__env->make('layouts.Product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>