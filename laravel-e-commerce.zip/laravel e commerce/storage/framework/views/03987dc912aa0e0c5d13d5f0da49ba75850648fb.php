<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
				<h3>User List</h3>
					<form>
						<label>KEYWORD: </label>
						<input type="text">
						<input type="submit" value="Search">
					</form>
					<br/>
					<table border="1">
						<tr>
							<th>FULL NAME</th>
							<th>USERNAME</th>
							<th>TYPE</th>
							<th>OPTION</th>
						</tr>
						<?php foreach($users as $usr): ?>
						<tr>
							<td><a href="details.html"><?php echo e($usr->fullName); ?></a></td>
							<td><?php echo e($usr->username); ?></td>
							<td><?php echo e($usr->type); ?></td>
							<td><a href="<?php echo e(Route('edit.index', [$usr->userId])); ?>">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr>
						<?php endforeach; ?>
						
						<!-- <tr>
							<td><a href="details.html">Sally</a></td>
							<td>sally</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr>
						<tr>
							<td><a href="details.html">James</a></td>
							<td>james</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr> -->
					</table>
				<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>