<?php $__env->startSection('login'); ?>
  active
<?php $__env->stopSection(); ?>


<?php $__env->startSection('stuff'); ?>
	<table border="0" width="100%">
		<tr>
			<td width="100"></td>
			<td align="center">
				<h1>User Manager</h1>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td align="center">
				<hr/>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td>
				<br/>
				<center>
				<h3>User Authentication</h3>
				<p>Please login first</p>
				<br>
					<form method="post" action="<?php echo e(route('login.verify')); ?>">
						<?php echo e(csrf_field()); ?>

						<table>
							<tr>
								<td>USERNAME: </td>
								<td><input type="text" name="username"></td>
							</tr>
							<tr>
								<td>PASSWORD: </td>
								<td><input type="password" name="password"></td>
							</tr>
							<tr>
								<td></td>
								<td><input type="submit" value="Login"></td>
							</tr>
							<tr>
								<td></td>
								<td>
									<br/>
									Click <a href="<?php echo e(route('register.index')); ?>">here</a> to register
								</td>
							</tr>
						</table>
					</form>
					<br/>
					<br/>
					<label><?php if(isset($message)): ?>
								<?php echo e($message); ?>

							<?php endif; ?>
						</label>
				</center>
			</td>
			<td width="100"></td>
		</tr>
	</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.format', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>