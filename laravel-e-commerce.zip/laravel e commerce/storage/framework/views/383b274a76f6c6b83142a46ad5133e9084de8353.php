<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
				<h3>Product List</h3>
				<a href="<?php echo e(Route('categories.add')); ?>">Add New Category</a>
				  <?php if(Session::has('msg')): ?>
				    <h2 style="color:green"><?php echo e(Session::get('msg')); ?></h2>
				  <?php endif; ?>
				  <br>
					<br/>
					<table border="1">
						<tr>
							<th>ID</th>
							<th>NAME</th>
							<th>OPTION</th>
						</tr>
						<?php foreach($categories as $category): ?>
						<tr>
							<td width="25px"><?php echo e($category->id); ?></td>
							<td><?php echo e($category->cName); ?></td>
							<td><a href="<?php echo e(Route('categories.edit', [$category->id])); ?>">Edit</a> | <a href="<?php echo e(Route('categories.delete', [$category->id])); ?>">Delete</a></td>
						</tr>
						<?php endforeach; ?>
						
						<!-- <tr>
							<td><a href="details.html">Sally</a></td>
							<td>sally</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr>
						<tr>
							<td><a href="details.html">James</a></td>
							<td>james</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr> -->
					</table>
				<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>