<!DOCTYPE html>
<html>
<head>
	<title>E Commerce</title>
  <link href="<?php echo e(asset('/css/bootstrap.css')); ?>" rel="stylesheet"> 
  <link href="<?php echo e(asset('/css/jquery-ui.css')); ?>" rel="stylesheet"> 
    <script src="<?php echo e(asset('/js/jquery.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/jquery-ui.js')); ?>"></script>

  <script>
  $( function() {
    $( "#datepicker" ).datepicker({ yearRange: "-100:+0", changeMonth: true,
            changeYear: true, }).datepicker( "option", "dateFormat", "yy-mm-dd" );
  } );
  </script>

  <style type="text/css">
  footer{
   background-color: #222222;
  margin-top: 20px;
    height: 32px;
    text-align: center;
    color: #CCC;
}

footer p {
    padding: 8.5px;
    margin: 0px;
    line-height: 100%;
}

footer p span{
  font-weight: bold;
}

.ui-datepicker select.ui-datepicker-month, .ui-datepicker select.ui-datepicker-year {
    color:black;
}

</style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header"  style="padding-left:15px; padding-right:20px">
      <a class="navbar-brand" href="/">E-commerce</a>
    </div>
    <ul class="nav navbar-nav pull-right">
      <li class="<?php echo $__env->yieldContent('home'); ?>"><a href="/">Home</a></li>
      <li class="<?php echo $__env->yieldContent('products'); ?>"><a href="<?php echo e(route('products.index')); ?>">Products</a></li>
      <?php if(Session::has('loggedUser')): ?>
        <?php if(Session::get('loggedUser')->type=='Admin'): ?>
          <li class="<?php echo $__env->yieldContent('admin.home'); ?>"><a href="<?php echo e(route('admin.home')); ?>">Profile Home</a></li>
        <?php else: ?>
          <li class="<?php echo $__env->yieldContent('cart'); ?>"><a href="<?php echo e(route('cart.index')); ?>">Cart</a></li>
          <li class="<?php echo $__env->yieldContent('user.home'); ?>"><a href="<?php echo e(route('user.home')); ?>">Profile Home</a></li>
        <?php endif; ?>
        <li><a href="<?php echo e(route('logout.index')); ?>">Logout</a></li>
      <?php else: ?>
        <li class="<?php echo $__env->yieldContent('cart'); ?>"><a href="<?php echo e(route('cart.index')); ?>">Cart</a></li>
        <li class="<?php echo $__env->yieldContent('login'); ?>"><a href="<?php echo e(route('login.index')); ?>">Login</a></li>
        <li class="<?php echo $__env->yieldContent('register'); ?>"><a href="<?php echo e(route('register.index')); ?>">Register</a></li>
      <?php endif; ?>
    </ul>
  </div>
</nav>

<?php echo $__env->yieldContent('stuff'); ?>;



  <footer>
      <p>Developed By <span>Mushfiq, Dhrubo, Mithun and Mehedi</span></p>

  </footer>

</body>
</html>