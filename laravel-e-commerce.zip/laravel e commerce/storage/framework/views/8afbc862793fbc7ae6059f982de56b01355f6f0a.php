<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?> - User Manager</title>
</head>
<body>
	<table border="0" width="100%">
		<tr>
			<td width="100"></td>
			<td align="center">
				<h1>User Manager</h1>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td align="center">
				<hr/>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td align="center">
				<a href="<?php echo e(Route('user.home')); ?>">Home</a> | 
				<a href="<?php echo e(Route('user.profile')); ?>">Profile</a> | 
				<a href="<?php echo e(Route('user.settings')); ?>">Settings</a> | 
				<a href="<?php echo e(Route('logout.index')); ?>">Logout</a>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td>
				<br/>
				<center>
					<?php echo $__env->yieldContent('contents'); ?>
				</center>
			</td>
			<td width="100"></td>
		</tr>
	</table>
</body>
</html>