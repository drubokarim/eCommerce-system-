<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

				<h3>Create new product</h3>
				<form method="post" action="<?php echo e(Route('products.store')); ?>" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

					
						<table>
							<tr>
								<td>PRODUCT NAME: </td>
								<td><input type="text" name="pname"></td>
							</tr>
							<tr>
								<td>DESCRIPTION: </td>
								<td><input type="text" name="description" ></td>
							</tr>
							<tr>
								<td>PRICE: </td>
								<td><input type="text" name="price" ></td>
							</tr>
							<tr>
								<td>PRODUCT IMAGE: </td>
								<td><input type="file" name="pic"></td>
							</tr>

							<tr>
								<td>CATEGORY</td>
								<td>
									<select name="category">
										<?php foreach($categories as $cat): ?>										   
										   	<option value="<?php echo e($cat->id); ?>"><?php echo e($cat->cName); ?></option>									   
										<?php endforeach; ?>
									</select>
								</td>
							</tr>
							
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<input type="submit" value="Create">
									</center>
								</td>
							</tr>
						</table>
					</form>
					<label>
					<?php if($errors->any()): ?>
		              <?php foreach($errors->all() as $err): ?>
			            <p><?php echo e($err); ?></p>
		              <?php endforeach; ?>
	                <?php endif; ?>
					</label>
<?php $__env->stopSection(); ?>			
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>