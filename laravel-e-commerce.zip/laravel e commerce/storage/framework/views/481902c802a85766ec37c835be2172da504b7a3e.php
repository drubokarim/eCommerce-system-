<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
<h3>Admin Home</h3>
<p>Welcome <strong><?php echo e($uname); ?></strong></p>
<p>Your last login was on <?php echo e(Session::get('lastlog')); ?> PM</p>
				
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>