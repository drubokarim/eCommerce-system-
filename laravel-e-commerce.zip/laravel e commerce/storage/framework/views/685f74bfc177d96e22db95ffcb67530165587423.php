<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
<h3>Product Details</h3>
				
						<table>
							<tr>
								<td>CATEGORY NAME: </td>
								<td>
									
                                      <?php echo e($category->cName); ?>

									
								</td>
							</tr>
							
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<a href="<?php echo e(Route('categories.settings')); ?>">Back</a>
									</center>
								</td>
							</tr>
						</table>
						<h4>Are you sure that you want to delete this category?</h4> 
						<form method="post"> 
							<?php echo e(csrf_field()); ?> 
							<input type="hidden" name="categoryId" value="<?php echo e($category->id); ?>"> 
							<input type="submit" value="Confirm">
						
						 </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>