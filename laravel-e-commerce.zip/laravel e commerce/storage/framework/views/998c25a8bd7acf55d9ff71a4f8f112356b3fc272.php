<?php $__env->startSection('cart'); ?>
  active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('stuff'); ?>


<center>
<h1>Cart</h1>
<hr></hr>

<?php if($errors->any()): ?>
    <?php foreach($errors->all() as $err): ?>
      <p style="color:red"><?php echo e($err); ?></p>
    <?php endforeach; ?>
  <?php endif; ?>
<?php if(Session::has('cart') && !empty(Session::get('cart'))): ?>
<table border="1" style="text-align:center"; >
  <tr>
    <th>Serial No</th> 
    <th>Product</th> 
    <th>Quantity</th>
    <th>Unit Price</th>
    <th>Total Price</th>
    <th>Options</th>
  </tr>

  <?php $count=1; $total=0;  ?>

    <?php foreach(Session::get('cart') as $product_id=>$quantity): ?>
      <?php foreach($products as $key => $product): ?>
        <?php if($product->pId==$product_id): ?>
        <form action="<?php echo e(Route('cart.updateQuantity')); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <tr>
            <td><?php echo e($count); ?> </td>
            <td><?php echo e($product->name); ?></td>
            <input type="text" name="id" value="<?php echo e($product_id); ?>" hidden="hidden">
            <td width="100px" height="32px;"><input type="text" name="quantity" value="<?php echo e($quantity); ?>" style=" text-align: center; height:23px; width:70px;"></input></td>
            <td><?php echo e($product->price); ?></td>
            <td><?php echo e($product->price*$quantity); ?></td>
            <td><input type="submit" class="btn-success" value="Update"></input> | <button class="btn-danger"><a style="color:white;" href="<?php echo e(Route('cart.remove',[$product->pId])); ?>" onclick="alert('remove?')">Remove</a></button></td>
          </tr>
        </form>

        <?php $total+=$product->price*$quantity; ?>
        <?php endif; ?>
      <?php endforeach; ?>
      <?php $count++;?>
    <?php endforeach; ?>

</table>
  <p>Grand Total:<?php echo e($total); ?></p>

  <form action="<?php echo e(Route('order.place')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <input type="text" name="price" value="<?php echo e($total); ?>" hidden="hidden"></input>
    <label>Phone Number</label><br>
    <input type="text" name="phone" value="<?php echo e(isset($orders->phone) ? $orders->phone : ''); ?>"</input><br>
    <label>Shipping Address</label><br>
    <textarea name="address" cols="50" rows="5"><?php echo e(isset($orders->address) ? $orders->address : ''); ?> </textarea><br>
    <input type="submit" class="btn-success" value="Place Order" onclick="alert('confirm?');"></input>
  </form>
  

  <?php else: ?>
    <p>The Cart is Empty!</p>
    
  <?php endif; ?>

  <?php if(Session::has('msg')): ?>
    <h2><?php echo e(Session::get('msg')); ?></h2>
  <?php endif; ?>

</center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.format', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>