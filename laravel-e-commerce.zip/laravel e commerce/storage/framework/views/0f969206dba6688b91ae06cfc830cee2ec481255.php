<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

<h3>Edit Product Information</h3>
				<form method="post" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

					<input type="hidden" name="productId" value="<?php echo e($product->pId); ?>">
						<table>
							<tr>
								<td>PRODUCT NAME: </td>
								<td><input type="text" name="pname" value="<?php echo e($product->name); ?>"></td>
							</tr>
							<tr>
								<td>DESCRIPTION: </td>
								<td><input type="text" name="description" value="<?php echo e($product->description); ?>"></td>
							</tr>
							<tr>
								<td>PRICE: </td>
								<td><input type="text" name="price" value="<?php echo e($product->price); ?>"></td>
							</tr>
							<tr>
								<td>Category: </td>
								<td>
									<select name="category">
								   		<option value="<?php echo e($product->categoryId); ?>"><?php echo e($product->cName); ?></option>	
										<?php foreach($categories as $cat): ?>
											<?php if($cat->id!=$product->categoryId): ?>
										   		<option value="<?php echo e($cat->id); ?>"><?php echo e($cat->cName); ?></option>							
										   	<?php endif; ?>
										<?php endforeach; ?>
									</select>
								</td>
							</tr>
							<tr>
								<td>CURRENT IMAGE: </td>
								<td><img src="<?php echo e($product->img); ?>" style="width:180px; height:auto;"></td>
							</tr>
							<tr>
								<td>CHANGE IMAGE: </td>
								<td><input type="file" name="pic" value="<?php echo e($product->img); ?>"></td>
							</tr>
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<a href="<?php echo e(Route('products.settings')); ?>">Back</a> | 
										<input type="submit" value="Update">
									</center>
								</td>
							</tr>
						</table>
					</form>
					<br/>
					<br/>
					<label>
					<?php if($errors->any()): ?>
		              <?php foreach($errors->all() as $err): ?>
			            <p><?php echo e($err); ?></p>
		              <?php endforeach; ?>
	                <?php endif; ?>
					</label>				

					<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>