<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
<h3>Product Details</h3>
				
						<table>
							<tr>
								<td>PRODUCT NAME: </td>
								<td>
									
                                      <?php echo e($product->name); ?>

									
								</td>
							</tr>
							<tr>
								<td>DESCRIPTION: </td>
								<td>
                                    
                                      <?php echo e($product->description); ?>

									
								</td>
							</tr>
							<tr>
								<td>PRICE: </td>
								<td>
									  <?php echo e($product->price); ?>

									
								</td>
							</tr>
							<tr>
								<td>CATEGORY: </td>
								<td>
									 <?php echo e($product->cName); ?>

								</td>
							</tr>
							<tr>
								<td>PICTURE: </td>
								<td>
									<img src="<?php echo e($product->img); ?>" style="width:200px; height:auto;">
								</td>
							</tr>
							
							
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<a href="<?php echo e(Route('products.settings')); ?>">Back</a>
									</center>
								</td>
							</tr>
						</table>
						<h4>Are you sure that you want to delete this product?</h4> 
						<form method="post"> 
							<?php echo e(csrf_field()); ?> 
							<input type="hidden" name="productId" value="<?php echo e($product->pId); ?>"> 
							<input type="submit" value="Confirm">
						
						 </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>