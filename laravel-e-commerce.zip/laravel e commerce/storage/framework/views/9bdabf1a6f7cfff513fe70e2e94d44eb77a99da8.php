<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
				<h3>Orders List</h3>
				<?php if(Session::has('msg')): ?>
			 	   <h2 style="color:green;"><?php echo e(Session::get('msg')); ?></h2>
				<?php endif; ?>
					<br/>
					<table border="1" style="text-align:center">
						<tr>
							<th>ORDER ID</th>
							<th>PRODUCTS</th>
							<th>CUSTOMER ID</th>
							<th>CUSTOMER NAME</th>
							<th>TOTAL PRICE</th>
							<th>SHIPPING ADDRESS</th>
							<th>PHONE NUMBER</th>
							<th>ORDER DATE</th>
							<th>ORDER STATUS</th>
						</tr>
						<?php $count=1;?>
						<?php foreach($orders as $order): ?>
						<tr>
							<td><?php echo e($order->orderId); ?></td>
							<?php $prods = json_decode($order->products,true);?>
							
								<?php $prods = json_decode($order->products,true); ?>
									<?php $count2=1;?>
								<td><?php foreach($prods as $prod): ?>					
								<span style="font-weight:bold">item <?php echo e($count2); ?>:</span>  <?php echo e($prod['quantity']); ?> piece(s) <?php echo e($prod['pName']); ?>-><?php echo e($prod['pPrice']); ?> tk per piece 
								<br>
								<?php $count2++; ?>
								<?php endforeach; ?>
							
							<td><?php echo e($order->customerId); ?></td>
							<td><?php echo e($order->fullName); ?></td>
							<td><?php echo e($order->price); ?></td>
							<td><?php echo e($order->address); ?></td>
							<td><?php echo e($order->phone); ?></td>
							<td><?php echo e($order->orderDate); ?></td>
							<td>
								<form method="post">
								<?php echo e(csrf_field()); ?>

									<select name="status">
										<?php if($order->status=='Processed'): ?>
											<option value="Processed">Processed</option>
											<option value="Pending">Pending</option>
											<option value="Delivered">Delivered</option>
										<?php elseif($order->status=='Delivered'): ?>
											<option value="Delivered">Delivered</option>
											<option value="Pending">Pending</option>
											<option value="Processed">Processed</option>
										<?php else: ?>
											<option value="Pending">Pending</option>
											<option value="Processed">Processed</option>
											<option value="Delivered">Delivered</option>
										<?php endif; ?>
									</select>					
									<input type="text" name="id" value="<?php echo e($order->orderId); ?>" hidden="hidden">
									<input type="submit" value="Update">
								</form>
							</td>
						</tr>
						<?php $count++; ?>
						<?php endforeach; ?>
						
						<!-- <tr>
							<td><a href="details.html">Sally</a></td>
							<td>sally</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr>
						<tr>
							<td><a href="details.html">James</a></td>
							<td>james</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr> -->
					</table>

					
				<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>