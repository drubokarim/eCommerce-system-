<?php $__env->startSection('title'); ?>
Orders
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
				<h3>My Orders List</h3>
					<?php if(Session::has('msg')): ?>
				    	<h2 style="color:green; font-weight:bold;"><?php echo e(Session::get('msg')); ?></h2>
				    <?php endif; ?>
					<br/>
					<table border="1" style="text-align:center">
						<tr>
							<th>S.N.</th>
							<th>ORDER ID</th>
							<th>PRODUCT(S)</th>
							<th>TOTAL PRICE</th>
							<th>SHIPPING ADDRESS</th>
							<th>PHONE NUMBER</th>
							<th>ORDER DATE</th>
							<th>ORDER STATUS</th>
						</tr>
						<?php $count=1;?>
						<?php foreach($orders as $order): ?>
						<tr>
							<td><?php echo e($count); ?></td>
							<td><?php echo e($order->orderId); ?></td>
							<?php $prods = json_decode($order->products,true);?>
							<td>
							<?php $count2=1;?>

								<?php foreach($prods as $prod): ?>
							       <?php foreach($productsInfo as $p): ?>
										
								        <?php if($prod['pId']==$p->pId): ?>
								        	<p style="text-align:left; padding:0px 10px;"><span style="font-weight:bold">item <?php echo e($count2); ?>:</span> <?php echo e($prod['quantity']); ?> piece(s) <?php echo e($prod['pName']); ?>-><?php echo e($prod['pPrice']); ?> tk per piece</p>
								        <?php endif; ?>
								        
							       <?php endforeach; ?>
							       <?php $count2++; ?>
								<?php endforeach; ?>
							</td>
							<td><?php echo e($order->price); ?></td>
							<td><?php echo e($order->address); ?></td>
							<td><?php echo e($order->phone); ?></td>
							<td><?php echo e($order->orderDate); ?></td>
							<td style="color:#4caf50; font-weight:bold;"><?php echo e($order->status); ?></td>
						</tr>
						<?php $count++; ?>
						<?php endforeach; ?>
						
						<!-- <tr>
							<td><a href="details.html">Sally</a></td>
							<td>sally</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr>
						<tr>
							<td><a href="details.html">James</a></td>
							<td>james</td>
							<td>User</td>
							<td><a href="edit.html">Edit</a> | <a href="delete.html">Delete</a></td>
						</tr> -->
					</table>

					
				<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>