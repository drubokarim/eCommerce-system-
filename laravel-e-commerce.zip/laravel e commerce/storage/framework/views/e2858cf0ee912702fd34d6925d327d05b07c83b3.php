<?php $__env->startSection('title'); ?>
Report
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
				<h3>User Statistics</h3>
					<table border="1">
						<tr>
							<th>USER TYPE</th>
							<th>TOTAL USER</th>
						</tr>
						<tr>
							<td>Admin</td>
							<td><?php echo e($admin); ?></td>
						</tr>
						<tr>
							<td>User</td>
							<td><?php echo e($user); ?></td>
						</tr>
					</table>
					<br/>

					<h3>Best Buyer</h3>
					<table border="1" style="text-align:center;">
						<tr>
							<th>CUSTOMER ID</th>
							<th>CUSTOMER NAME</th>
							<th>NUMBER OF BOUGHT PRODUCTS</th>
							<th>TOTAL SPENT</th>
						</tr>

								
						<tr>
							<td><?php echo e($bestCustId); ?></td>
							<td><?php echo e($bestCustName); ?></td>
							<td><?php echo e($max); ?></td>
							<td><?php echo e($bestCustSpent); ?></td>
						</tr>
					</table>

					<h3>User Activity</h3>
					<table border="1">
						<tr>
							<th>INACTIVE SINCE</th>
							<th>TOTAL USER</th>
							<th>DETAILS</th>
						</tr>
						<tr>
							<?php $cat1=$cat2=$cat3=$cat4=0;?>
								<?php foreach($inactivity as $id => $month): ?>	
									<?php if($month>3 && $month<6): ?>
										<?php $cat1++;?>
										
									<?php elseif($month>6 && $month<9): ?>
										<?php $cat2++;?>

									<?php elseif($month>9 && $month<12): ?>
										<?php $cat3++;?>
									
									<?php elseif($month>12): ?>
										<?php $cat4++;?>
									
									<?php endif; ?>
								<?php endforeach; ?>
							</td>

							<td>3 - 6 Months</td>
							<td><?php echo e($cat1); ?></td>
							
							<td><a href="<?php echo e(Route('report.details', [1])); ?>">Details</a></td>
						</tr>
						<tr>
							<td>6 - 9 Months</td>
							<td><?php echo e($cat2); ?></td>
							<td><a href="<?php echo e(Route('report.details', [2])); ?>">Details</a></td>
						</tr>
						<tr>
							<td>9 - 12 Months</td>
							<td><?php echo e($cat3); ?></td>
							<td><a href="<?php echo e(Route('report.details', [3])); ?>">Details</a></td>
						</tr>
						<tr>
							<td>More than 12 Months</td>
							<td><?php echo e($cat4); ?></td>
							<td><a href="<?php echo e(Route('report.details', [4])); ?>">Details</a></td>
						</tr>
					</table>

					
				</center>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>