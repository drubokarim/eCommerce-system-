<?php $__env->startSection('title'); ?>
Delete
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
				<h3>Delete User</h3>
				<form method="post">
				<?php echo e(csrf_field()); ?>

						<table>
							<tr>
								<td>FULL NAME: </td>
								<td><?php echo e($fullName); ?></td>
							</tr>
							<tr>
								<td>EMAIL: </td>
								<td><?php echo e($email); ?></td>
							</tr>
							<tr>
								<td>USERNAME: </td>
								<td><?php echo e($username); ?></td>
							</tr>
							<tr>
								<td>TYPE: </td>
								<td><?php echo e($type); ?></td>
							</tr>
							<tr>
								<td>LAST LOGIN: </td>
								<td><?php echo e($lastLogin); ?></td>
							</tr>
							<tr>
								<td colspan="2">
									<br/>
									<center><strong>Are you sure to delete this user?</strong></center>
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<a href="users.html">Back</a> | 
										<input type="submit" value="Confirm">
									</center>
								</td>
							</tr>
						</table>
					</form>
					<br/>
					<br/>
					<label>Any message goes here</label>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>