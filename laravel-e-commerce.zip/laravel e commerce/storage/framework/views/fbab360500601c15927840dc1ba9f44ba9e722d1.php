<?php $__env->startSection('title'); ?>
Report
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
				<h3>User Statistics</h3>
					<table border="1">
						<tr>
							<th>USER TYPE</th>
							<th>TOTAL USER</th>
						</tr>
						<tr>
							<td>Admin</td>
							<td><?php echo e($admin); ?></td>
						</tr>
						<tr>
							<td>User</td>
							<td><?php echo e($user); ?></td>
						</tr>
					</table>
					<br/>
					<br/>
					<h3>User Activity</h3>
					<table border="1">
						<tr>
							<th>INACTIVE SINCE</th>
							<th>TOTAL USER</th>
							<th>DETAILS</th>
						</tr>
						<tr>
							<td>3 - 6 Months</td>
							<td><?php echo e($month); ?></td>
							<td><a href="#">Details</a></td>
						</tr>
						<tr>
							<td>6 - 9 Months</td>
							<td>0</td>
							<td><a href="#">Details</a></td>
						</tr>
						<tr>
							<td>9 - 12 Months</td>
							<td>0</td>
							<td><a href="#">Details</a></td>
						</tr>
						<tr>
							<td>More than 12 Months</td>
							<td>1</td>
							<td><a href="#">Details</a></td>
						</tr>
					</table>
				</center>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>