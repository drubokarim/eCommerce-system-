<?php $__env->startSection('title'); ?>
	Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
<center>
<h3>My Profile</h3>
<form method="post">
		<table>
			<tr>
				<td>FULL NAME: </td>
				<td><?php echo e($fname); ?></td>
			</tr>
			<tr>
				<td>EMAIL: </td>
				<td><?php echo e($email); ?></td>
			</tr>
			<tr>
				<td>USERNAME: </td>
				<td><?php echo e($uname); ?></td>
			</tr>
			<tr>
				<td>TYPE: </td>
				<td><?php echo e($type); ?></td>
			</tr>
			<tr>
				<td colspan="2">
					<br/>
					<center>
						<a href="<?php echo e(url()->previous()); ?>">Back</a> | 
						<a href="<?php echo e(Route('user.edit')); ?>">Edit</a>
					</center>
				</td>
			</tr>
		</table>
	</form>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>