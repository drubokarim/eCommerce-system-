<?php $__env->startSection('register'); ?>
  active
<?php $__env->stopSection(); ?>


<?php $__env->startSection('stuff'); ?>

	<table border="0" width="100%">
		<tr>
			<td width="100"></td>
			<td align="center">
				<h1>User Manager</h1>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td align="center">
				<hr/>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td>
				<br/>
				<center>
				<h3>New User Registration</h3>
				<form method="post" action="#">
					<?php echo e(csrf_field()); ?>

						<table>
							<tr>
								<td>FULL NAME: </td>
								<td><input type="text" name="name"></td>
							</tr>
							<tr>
								<td>EMAIL: </td>
								<td><input type="text" name="email"></td>
							</tr>
							<tr>
								<td>DATE OF BIRTH: </td>
								<td><input type="text" id="datepicker" name="dob"></td>
							</tr>
							<tr>
								<td>USERNAME: </td>
								<td><input type="text" name="username"></td>
							</tr>
							<tr>
								<td>PASSWORD: </td>
								<td><input type="password" name="pass"></td>
							</tr>
							<tr>
								<td>RE-PASSWORD: </td>
								<td><input type="password" name="con_pass"></td>
							</tr>
							<tr>
								<td></td>
								<td><input type="submit" value="Register"></td>
							</tr>
							<tr>
								<td></td>
								<td>
									<br/>
									Click <a href="<?php echo e(route('login.index')); ?>">here</a> to login
								</td>
							</tr>
						</table>
					</form>
					<br/>
					<br/>
					<label><?php if($errors->any()): ?>
								<?php foreach($errors->all() as $err): ?>
									<?php echo e($err); ?>

								<?php endforeach; ?>
							<?php endif; ?>

					</label>
				</center>
			</td>
			<td width="100"></td>
		</tr>
	</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.format', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>