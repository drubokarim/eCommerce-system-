<?php $__env->startSection('title'); ?>
Settings
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
				<h3>Change Password</h3>
				<form method="post">
				<?php echo e(csrf_field()); ?>

						<table>
							<tr>
								<td>USERNAME: </td>
								<td><?php echo e($uname); ?></td>
							</tr>
							<tr>
								<td>OLD PASSWORD: </td>
								<td><input type="password" name="oldPass"></td>
							</tr>
							<tr>
								<td>NEW PASSWORD: </td>
								<td><input type="password" name="newPass"></td>
							</tr>
							<tr>
								<td>RE-TYPE PASSWORD: </td>
								<td><input type="password" name="conPass"></td>
							</tr>
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<a href="<?php echo e(url()->previous()); ?>">Back</a> | 
										<input type="submit" value="Update">
									</center>
								</td>
							</tr>
						</table>
					</form>
					<br/>
					<br/>
					<label><?php if($errors->any()): ?>
				<?php foreach($errors->all() as $err): ?>
					<?php echo e($err); ?>

				<?php endforeach; ?>
			<?php endif; ?></label>
				</center>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>