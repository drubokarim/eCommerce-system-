<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

				<h3>Create New Category</h3>
				<form method="post" action="<?php echo e(Route('categories.store')); ?>" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

					
						<table>
							<tr>
								<td>CATEGORY NAME: </td>
								<td><input type="text" name="cname"></td>
							</tr>
							
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<input type="submit" value="Create">
									</center>
								</td>
							</tr>
						</table>
					</form>
					<br/>
					<br/>
					<label>
					<?php if($errors->any()): ?>
		              <?php foreach($errors->all() as $err): ?>
			            <p><?php echo e($err); ?></p>
		              <?php endforeach; ?>
	                <?php endif; ?>
	                
					</label>
<?php $__env->stopSection(); ?>			
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>