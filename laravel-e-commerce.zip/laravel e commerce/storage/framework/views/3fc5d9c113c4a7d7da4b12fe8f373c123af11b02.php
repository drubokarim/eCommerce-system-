<?php $__env->startSection('title'); ?>
Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
				<h3>User Details</h3>
				<?php if($cat==1): ?>
					<h2>Inactivity 3-6 months</h2>
				<?php elseif($cat==2): ?>
					<h2>Inactivity 6-9 months</h2>
				<?php elseif($cat==3): ?>
					<h2>Inactivity 9-12 months</h2>
				<?php elseif($cat==4): ?>
					<h2>Inactivity more than 12 months</h2>
				<?php endif; ?>
						
				<?php foreach($profiles as $profile): ?>

				
				<?php $a=$inactivity[$profile->userId];?>

				<?php if($a>3 && $a<6 && $cat==1): ?>
					<table border="1px" style="text-align:center;">
						<tr>
							<td>FULL NAME: </td>
							<td><?php echo e($profile->fullName); ?></td>
						</tr>
						<tr>
							<td>EMAIL: </td>
							<td><?php echo e($profile->email); ?></td>
						</tr>
						<tr>
							<td>USERNAME: </td>
							<td><?php echo e($profile->username); ?></td>
						</tr>
						<tr>
							<td>LAST LOGIN: </td>
							<td><?php echo e($profile->lastLogin); ?></td>
						</tr>
						<br>
					</table>

					<?php elseif($a>6 && $a<9 && $cat==2): ?>
					<table border="1px" style="text-align:center;">
						<tr>
							<td>FULL NAME: </td>
							<td><?php echo e($profile->fullName); ?></td>
						</tr>
						<tr>
							<td>EMAIL: </td>
							<td><?php echo e($profile->email); ?></td>
						</tr>
						<tr>
							<td>USERNAME: </td>
							<td><?php echo e($profile->username); ?></td>
						</tr>
						<tr>
							<td>LAST LOGIN: </td>
							<td><?php echo e($profile->lastLogin); ?></td>
						</tr>
						<br>
					</table>

					<?php elseif($a>9 && $a<12 && $cat==3): ?>
					<table border="1px" style="text-align:center;">
						<tr>
							<td>FULL NAME: </td>
							<td><?php echo e($profile->fullName); ?></td>
						</tr>
						<tr>
							<td>EMAIL: </td>
							<td><?php echo e($profile->email); ?></td>
						</tr>
						<tr>
							<td>USERNAME: </td>
							<td><?php echo e($profile->username); ?></td>
						</tr>
						<tr>
							<td>LAST LOGIN: </td>
							<td><?php echo e($profile->lastLogin); ?></td>
						</tr>
						<br>
					</table>

					<?php elseif($a>12 && $cat==4): ?>
					<table border="1px" style="text-align:center;">
						<tr>
							<td>FULL NAME: </td>
							<td><?php echo e($profile->fullName); ?></td>
						</tr>
						<tr>
							<td>EMAIL: </td>
							<td><?php echo e($profile->email); ?></td>
						</tr>
						<tr>
							<td>USERNAME: </td>
							<td><?php echo e($profile->username); ?></td>
						</tr>
						<tr>
							<td>LAST LOGIN: </td>
							<td><?php echo e($profile->lastLogin); ?></td>
						</tr>
						<br>
					</table>

				<?php endif; ?>		
						
				<?php endforeach; ?>
					<center>
						<a href="<?php echo e(url()->previous()); ?>">Back</a>
					</center>

				</center>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>