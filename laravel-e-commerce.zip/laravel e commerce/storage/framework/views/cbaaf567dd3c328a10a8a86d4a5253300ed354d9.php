<?php $__env->startSection('home'); ?>
  active
<?php $__env->stopSection(); ?>


<?php $__env->startSection('stuff'); ?>
<div style="min-height:485px;">
	<h1 style="padding-top: 220px; text-align:center;">Welcome to E-Commerce Site. Browse through the topbar menus for shopping.</h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.format', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>