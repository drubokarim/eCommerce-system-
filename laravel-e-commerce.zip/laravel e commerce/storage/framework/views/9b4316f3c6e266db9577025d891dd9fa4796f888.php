<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?> - User Manager</title>
  <link href="<?php echo e(asset('/css/bootstrap.css')); ?>" rel="stylesheet"> 
	<link href="<?php echo e(asset('/js/jquery.js')); ?>" rel="stylesheet"> 
	<style type="text/css">

  footer{
   background-color: #222222;
     margin-top: 20px;
    height: 35px;
    text-align: center;
    color: #CCC;
}

footer p {
    padding: 10.5px;
    margin: 0px;
    line-height: 100%;
}

footer p span{
  font-weight: bold;
}

</style>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header"  style="padding-left:15px; padding-right:20px">
      <a class="navbar-brand" href="#">Ecommerce</a>
    </div>
    <ul class="nav navbar-nav pull-right">
      <li><a href="/">Home</a></li>
      <li><a href="<?php echo e(route('products.index')); ?>">Products</a></li>
      <li><a href="<?php echo e(route('cart.index')); ?>">Cart</a></li>
      <?php if(Session::has('loggedUser')): ?>
        <?php if(Session::get('loggedUser')->type=='Admin'): ?>
      		<li class="<?php echo $__env->yieldContent('admin.home'); ?>"><a href="<?php echo e(route('admin.home')); ?>">Profile Home</a></li>
      	<?php else: ?>
      		<li class="<?php echo $__env->yieldContent('user.home'); ?>"><a href="<?php echo e(route('user.home')); ?>">Profile Home</a></li>
      	<?php endif; ?>
        <li><a href="<?php echo e(route('logout.index')); ?>">Logout</a></li>
      <?php else: ?>
        <li><a href="<?php echo e(route('login.index')); ?>">Login</a></li>
        <li><a href="<?php echo e(route('register.index')); ?>">Register</a></li>
      <?php endif; ?>
    </ul>
  </div>
</nav>

	<table border="0" width="100%">
		<tr>
			<td width="100"></td>
			<td align="center">
				<h1>User Manager</h1>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td align="center">
				<hr/>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td align="center">
				<a href="<?php echo e(Route('user.home')); ?>">Home</a> | 
				<a href="<?php echo e(Route('user.profile')); ?>">Profile</a> | 
				<a href="<?php echo e(Route('user.settings')); ?>">Settings</a> | 
				<a href="<?php echo e(Route('order.userOrder')); ?>">Orders</a> | 
				<a href="<?php echo e(Route('logout.index')); ?>">Logout</a>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td>
				<br/>
				<center>
					<?php echo $__env->yieldContent('contents'); ?>
				</center>
			</td>
			<td width="100"></td>
		</tr>
	</table>


  <footer>
      <p>Developed By <span>Mushfiq, Dhrubo, Mithun and Mehedi</span></p>

  </footer>

</body>
</html>