<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

<h3>Edit Product Information</h3>
				<form method="post" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

					<input type="hidden" name="categoryId" value="<?php echo e($category->id); ?>">
						<table>
							<tr>
								<td>CATEGORY NAME: </td>
								<td><input type="text" name="cname" value="<?php echo e($category->cName); ?>"></td>
							</tr>
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<a href="<?php echo e(Route('categories.settings')); ?>">Back</a> | 
										<input type="submit" value="Update">
									</center>
								</td>
							</tr>
						</table>
					</form>
					<br/>
					<br/>
					<label>
					<?php if($errors->any()): ?>
		              <?php foreach($errors->all() as $err): ?>
			            <p><?php echo e($err); ?></p>
		              <?php endforeach; ?>
	                <?php endif; ?>
					</label>				

					<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>