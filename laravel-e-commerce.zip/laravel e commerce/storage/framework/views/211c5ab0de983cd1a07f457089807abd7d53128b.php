<?php $__env->startSection('products'); ?>
  active
<?php $__env->stopSection(); ?>


<!-- 
<script type="text/javascript">
  $(function(){
    $('#addToCart').click(function(){
        $.ajax({
        	url: '/cart/'$('#id').html(),
        	
        	method: 'get',
        	/*data: {
        		id:$('#id').html();
        	},*/
        	success: function(respoonse){
        		alert(response);
        	} 

        });
    });
  })
</script> -->
<?php $__env->startSection('stuff'); ?>
<section class="body col-md-12">

	<?php foreach($categories as $key => $category): ?>
	<div class="category pull-left col-md-12">
			<h1><?php echo e($category->cName); ?></h1>
			<div class="row">
			<?php foreach($products as $key => $product): ?>
				<?php if($product->cName == $category->cName): ?>
				  <div class="col-md-3">
				     <div class="col-md-12" style="border:2px solid gray; text-align:center" >
						<img src="<?php echo e($product->img); ?>" style="width:250px; height:auto ">
						<h2><?php echo e($product->name); ?></h2>
						<p><?php echo e($product->description); ?></p>
						<p><span style="font-weight:bold">Price: </span><?php echo e($product->price); ?>/-</p>
						<a href="<?php echo e(route('cart.add', [$product->pId])); ?>"><button>add to cart</button></a>
				     </div>
				  </div>
				 <?php endif; ?>
			<?php endforeach; ?>
			</div>
		</div>
		<?php endforeach; ?>
</section>
<?php $__env->stopSection(); ?>

<?php if(Session::has('msg')): ?>
  <script>alert('Product Added To Cart')</script>
<?php endif; ?>

<?php echo $__env->make('layouts.format', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>