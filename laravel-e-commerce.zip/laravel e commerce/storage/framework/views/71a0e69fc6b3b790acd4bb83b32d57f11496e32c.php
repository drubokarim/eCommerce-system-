<?php $__env->startSection('title'); ?>
	Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
	<center>
	<h3>Edit User Information</h3>
	<form method="post">
	<?php echo e(csrf_field()); ?>

			<table>
				<tr>
					<td>FULL NAME: </td>
					<td><input type="text" value="<?php echo e($fullName); ?>" name="fullName"></td>
				</tr>
				<tr>
					<td>EMAIL: </td>
					<td><input type="text" value="<?php echo e($email); ?>" name="email"></td>
				</tr>
				<tr>
					<td colspan="2">
						<br/>
						<center>
							<a href="<?php echo e(url()->previous()); ?>">Back</a> | 
							<input type="submit" value="Update">
						</center>
					</td>
				</tr>
			</table>
		</form>
		<br/>
		<br/>
		<label><?php if($errors->any()): ?>
				<?php foreach($errors->all() as $err): ?>
					<?php echo e($err); ?>

				<?php endforeach; ?>
			<?php endif; ?></label>
	</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>