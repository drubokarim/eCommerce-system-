-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2017 at 03:18 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cName` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `cName`) VALUES
(1, 'Laptops'),
(2, 'Smartphones'),
(3, 'Headphones'),
(4, 'Monitors'),
(5, 'Printers');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `orderId` int(11) NOT NULL AUTO_INCREMENT,
  `products` text CHARACTER SET utf8 NOT NULL,
  `customerId` int(11) NOT NULL,
  `orderDate` datetime NOT NULL,
  `address` text CHARACTER SET utf8 NOT NULL,
  `phone` text NOT NULL,
  `price` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`orderId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderId`, `products`, `customerId`, `orderDate`, `address`, `phone`, `price`, `status`) VALUES
(4, '[{"pId":4,"pName":"ACER Monitor","pPrice":10000,"quantity":"2"},\n {"pId":4,"pName":"ACER Monitor","pPrice":10000,"quantity":"2"}]', 2, '2017-11-17 17:33:22', 's', '', 112000, 'Processed'),
(5, '[{"pId":1,"pName":"Dell XPS 13","pPrice":132000,"quantity":1},{"pId":3,"pName":"Bose QC35","pPrice":10000,"quantity":"2"}]', 2, '2017-11-17 17:56:05', 'asdsdsd asd as', '', 352000, 'Pending'),
(6, '[{"pId":2,"pName":"Iphone X","pPrice":110000,"quantity":"2"},{"pId":1,"pName":"Dell XPS 13","pPrice":132000,"quantity":1}]', 2, '2017-11-17 18:16:25', 'qweqweq', '', 292000, 'Delivered'),
(7, '[{"pId":2,"pName":"Iphone X","pPrice":110000,"quantity":1}]', 3, '2017-11-17 18:24:28', 'qwe', '', 80000, 'Processed'),
(8, '[{"pId":4,"pName":"ACER Monitor","pPrice":10000,"quantity":1}]', 3, '2017-11-17 19:04:58', 'asd', '', 56000, 'Processed'),
(9, '[{"pId":2,"pName":"Iphone X","pPrice":110000,"quantity":1},{"pId":4,"pName":"ACER Monitor","pPrice":10000,"quantity":1}]', 3, '2017-11-17 19:05:42', 'sda', '', 136000, 'Processed'),
(10, '[{"pId":1,"pName":"Dell XPS 13","pPrice":132000,"quantity":1},{"pId":3,"pName":"Bose QC35","pPrice":10000,"quantity":"2"}]', 3, '2017-11-17 19:05:59', 'ads', '', 352000, 'Processed'),
(11, '[{"pId":1,"pName":"Dell XPS 13","pPrice":132000,"quantity":1},{"pId":4,"pName":"ACER Monitor","pPrice":10000,"quantity":1}]', 3, '2017-11-17 19:07:52', 's', '', 188000, 'Delivered'),
(12, '[{"pId":2,"pName":"Iphone X","pPrice":110000,"quantity":1},{"pId":4,"pName":"ACER Monitor","pPrice":10000,"quantity":1}]', 3, '2017-11-17 19:08:39', '48 WEST AGARGAON, KOLOTAN VILLA', '', 136000, 'Delivered'),
(13, '[{"pId":1,"pName":"Dell XPS 13","pPrice":132000,"quantity":"2"},{"pId":3,"pName":"Bose QC35","pPrice":10000,"quantity":1}]', 3, '2017-11-17 19:09:36', 'qweqw', '', 374000, 'Delivered'),
(14, '[{"pId":4,"pName":"Samsung Galaxy S8","pPrice":56000,"quantity":"3"},{"pId":5,"pName":"Bose QC35","pPrice":10000,"quantity":"2"}]', 3, '2017-11-17 19:13:46', 'qwe qweqwe wewq eqw eqwe qweqw ew', '01676584412', 188000, 'Delivered'),
(15, '[{"pId":2,"pName":"HP Elitebook","pPrice":80000,"quantity":1}]', 4, '2017-11-17 19:46:24', 'abcde abcde abcde asd asdas ', '01676584412', 80000, 'Delivered'),
(16, '[{"pId":1,"pName":"Dell XPS 13","pPrice":132000,"quantity":1}]', 4, '2017-11-17 19:46:48', 'yasdad qweqwe qwe qwe qwe q eqwe we ', '01676584412', 132000, 'Delivered'),
(17, '[{"pId":5,"pName":"Bose QC35","pPrice":10000,"quantity":20}]', 2, '2017-11-17 20:10:26', 'qweqweq  qweqweq eq eqwe ', '01676584412', 10000, 'Delivered'),
(18, '[{"pId":4,"pName":"Samsung Galaxy S8","pPrice":56000,"quantity":"3"}]', 3, '2017-11-18 18:07:23', 'qwe qweqwe wewq eqw eqwe qweqw ew ', '01676584412', 168000, 'Delivered'),
(19, '[{"pId":13,"pName":"Lenevo Gaming Laptop","pPrice":67000,"quantity":"5"},{"pId":11,"pName":"Beats Solo","pPrice":10000,"quantity":1},{"pId":18,"pName":"Hp Montor","pPrice":10500,"quantity":"2"},{"pId":17,"pName":"Epson Printer","pPrice":4500,"quantity":1}]', 13, '2017-11-18 19:36:16', '56, kuratoli, dhaka 1216', '01992382420', 370500, 'Processed'),
(20, '[{"pId":13,"pName":"Lenevo Gaming Laptop","pPrice":67000,"quantity":1},{"pId":16,"pName":"Macbook Pro","pPrice":149000,"quantity":"4"}]', 13, '2017-11-18 20:05:47', '56, kuratoli, dhaka 1216 ', '01992382420', 663000, 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `pId` int(11) NOT NULL AUTO_INCREMENT,
  `img` text NOT NULL,
  `name` text CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `price` int(11) NOT NULL,
  `categoryId` int(11) NOT NULL,
  PRIMARY KEY (`pId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pId`, `img`, `name`, `description`, `price`, `categoryId`) VALUES
(1, '/photos/1510786396.jpg', 'Dell XPS 13', 'CPU	Intel Core i7-8550U Operating System	Windows 10 RAM	8GB RAM Upgradable to	16GB Hard Drive Size	256GB SSD', 132000, 1),
(2, '/photos/1510786645.jpg', 'HP Elitebook', 'CPU	Intel Core i7-8550U Operating System Windows 10 RAM 8GB RAM Upgradable to 16GB Hard Drive Size 128GB SSD', 80000, 1),
(3, '/photos/1510786751.jpg', 'Iphone X', '5.8 inches oled Apple A11 Bionic  Dual 12 MP, (28mm, f/1.8 & 52mm, f/2.4), OIS, phase detection autofocus, 2x optical zoom, quad-LED (dual tone) flash', 110000, 2),
(4, '/photos/1510786817.jpg', 'Samsung Galaxy S8', '5.8" 1440x2960 pixels 12MP 2160p  4GB RAM Exynos 8895 Octa', 56000, 2),
(5, '/photos/1510786862.jpg', 'Bose QC35', 'Noise Cancelling Bass Sounding Bluetooth Headphone', 10000, 3),
(6, '/photos/1510786934.jpg', 'ACER Monitor', 'asda asd asdasd asd as', 10000, 4),
(7, '/photos/1510787009.jpg', 'LG V30', '6.0" 1440x2880 pixels 16MP 2160p 4GB RAM Snapdragon 835', 45000, 2),
(8, '/photos/1510787056.jpg', 'curve monitor', 'Curved monitor 65 inch with oled screen ', 20000, 0),
(10, '/photos/1511011596.jpeg', 'JBL', 'Noise Cancelling Bass Sounding Bluetooth Headphone', 4000, 3),
(11, '/photos/1511011623.png', 'Beats Solo', 'Noise Cancelling Bass Sounding Bluetooth Headphone', 10000, 3),
(12, '/photos/1511011675.jpg', 'Canon Printer', 'Canon Color Printer with scanner', 5000, 5),
(13, '/photos/1511011740.jpg', 'Lenevo Gaming Laptop', '8gb ram, 2gb nvdia graphic card, 1tb hard disk', 67000, 1),
(14, '/photos/1511011817.jpg', 'Oneplus 5t', '6" oled 1080p scree, android nougat 5.1.1, bezel less design', 42000, 2),
(15, '/photos/1511011869.jpg', 'Lg Monitor', '1080p 21.5inch lg monitor', 11000, 4),
(16, '/photos/1511011938.jpg', 'Macbook Pro', '15" touchbar edition, 512gb ssd, 8gb ram', 149000, 1),
(17, '/photos/1511011993.png', 'Epson Printer', 'epson color printer with scanner', 4500, 5),
(18, '/photos/1511012043.jpg', 'Hp Montor', '21.5 inch monitor, 1080p resolution', 10500, 4),
(19, '/photos/1511014437.jpeg', 'samsung printer', 'color printer, photocopier and scanner', 7000, 5);

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE IF NOT EXISTS `profiles` (
  `userId` int(11) NOT NULL,
  `fullName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `dateOfBirth` date NOT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`userId`, `fullName`, `email`, `dateOfBirth`) VALUES
(2, 'Mushfiq Dewan', 'mushfiq20@yahoo.com', '1995-01-20'),
(3, 'Mithun', 'muthun@gmail.com', '1996-02-10'),
(4, 'Mahadi', 'mahadi@gmail.com', '1994-08-02'),
(5, 'Dhrubo', 'dhrubo@gmail.com', '1996-11-19'),
(13, 'user', 'user@user.com', '2017-11-08'),
(14, 'as', 'as@ad.com', '2017-11-06'),
(15, 'Sakib Al Hassan', 'alhassan@gmail.com', '1999-02-11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` varchar(10) NOT NULL,
  `lastLogin` datetime NOT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `username`, `password`, `type`, `lastLogin`) VALUES
(1, 'admin', 'admin01', 'Admin', '2017-11-18 20:09:58'),
(2, 'mushfiq', 'mushfiq', 'User', '2017-11-18 20:02:47'),
(3, 'mithun', 'mithun', 'User', '2016-10-18 18:01:22'),
(4, 'mahadi', 'mahadi', 'User', '2017-03-17 19:37:26'),
(5, 'dhrubo', 'dhrubo', 'User', '2017-07-15 17:29:46'),
(13, 'user', 'user', 'User', '2017-11-18 20:05:37'),
(14, 'as', 'as', 'User', '2017-02-18 17:58:41'),
(15, 'sakib', 'sakib1', 'User', '2017-11-18 19:44:33');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
