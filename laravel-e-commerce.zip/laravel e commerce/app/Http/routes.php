<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});


Route::get('/login', 'LoginController@index')->name('login.index');

Route::post('/login', 'LoginController@verify')->name('login.verify');

Route::get('/register', 'RegisterController@index')->name('register.index');

Route::post('/register', 'RegisterController@store')->name('register.store');

Route::get('/logout', 'LogoutController@index')->name('logout.index');

Route::get('/cart/{id}', 'CartController@add')->name('cart.add');

Route::get('/products', 'ProductsController@index')->name('products.index');








Route::group(['middleware' => ['sess']], function(){

	Route::get('/profile', 'ProfileController@index')->name('user.profile');

	Route::get('/settings', 'SettingsController@index')->name('user.settings');

	Route::post('/settings', 'SettingsController@change')->name('user.settings.change');

	Route::get('/edit', 'EditController@index')->name('user.edit');

	Route::post('/edit', 'EditController@change')->name('user.edit.change');

	Route::get('/home', 'HomeController@index')->name('user.home');

	Route::get('/order', 'OrdersController@userOrder')->name('order.userOrder');
	
	Route::post('/order', 'OrdersController@place')->name('order.place');

	
	Route::get('/cart', 'CartController@index')->name('cart.index');

	Route::post('/cart', 'CartController@updateQuantity')->name('cart.updateQuantity');

	Route::get('/cart/remove/{id}', 'CartController@remove')->name('cart.remove');


	Route::group(['middleware' => ['admin']], function(){
		Route::get('/admin', 'AdminController@index')->name('admin.index');

		Route::get('/admin.home', 'AdminHomeController@index')->name('admin.home');


		Route::get('/admin.settings', 'AdminSettingsController@index')->name('admin.settings');

		Route::post('/admin.settings', 'AdminSettingsController@change')->name('admin.settings.change');


		Route::get('/report', 'ReportController@index')->name('admin.report');
		
		Route::get('/report/{cat}/details', 'ReportController@details')->name('report.details');

		Route::get('/admin.users', 'AdminUsersController@index')->name('admin.users');
		
		Route::get('/admin.products', 'ProductsController@settings')->name('products.settings');

		Route::get('/admin.products/{id}/edit', 'ProductsController@edit')->name('product.edit');
		Route::post('/admin.products/{id}/edit', 'ProductsController@update')->name('product.update');
		
		Route::get('/admin.products/{id}/delete', 'ProductsController@delete')->name('product.delete');
		Route::post('/admin.products/{id}/delete', 'ProductsController@destroy')->name('product.destroy');
		
		Route::get('/admin.products/add', 'ProductsController@add')->name('products.add');

		Route::post('/admin.products/add', 'ProductsController@store')->name('products.store');



		Route::get('/admin.category', 'CategoriesController@settings')->name('categories.settings');

		Route::get('/admin.category/{id}/edit', 'CategoriesController@edit')->name('categories.edit');
		Route::post('/admin.category/{id}/edit', 'CategoriesController@update')->name('categories.update');
		
		Route::get('/admin.category/{id}/delete', 'CategoriesController@delete')->name('categories.delete');
		Route::post('/admin.category/{id}/delete', 'CategoriesController@destroy')->name('categories.destroy');
		
		Route::get('/admin.category/add', 'CategoriesController@add')->name('categories.add');

		Route::post('/admin.category/add', 'CategoriesController@store')->name('categories.store');


		
		Route::get('/admin.orders', 'OrdersController@index')->name('orders.index');

		Route::post('/admin.orders', 'OrdersController@changeStatus')->name('orders.changeStatus');

		Route::get('/admin.users/{id}/edit', 'AdminUsersController@edit')->name('edit.index');

		Route::post('/admin.users/{id}/edit', 'AdminUsersController@change')->name('edit.change');

		Route::get('/admin.users/{id}/delete', 'AdminUsersController@delete')->name('delete.index');

		Route::post('/admin.users/{id}/delete', 'AdminUsersController@destroy')->name('delete.destroy');

	});
	
	
});







