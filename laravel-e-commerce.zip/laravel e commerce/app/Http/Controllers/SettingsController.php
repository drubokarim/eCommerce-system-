<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;
use App\User;
use Validator;

class SettingsController extends Controller
{
    public function index(Request $request)
    {
    	$id=Session::get('id');

    	$user = DB::table('users')
            ->where('userId',$id)
            ->first();

    	return view('user.settings')
    	->with('uname', $user->username);
    }


    public function change(Request $request)
    {
    	$id=Session::get('id');
    	$user = DB::table('users')
            ->where('userId',$id)
            ->first();



    	if($user->password == $request->oldPass)
    	{
	    	 $validator = Validator::make($request->all(), [

	            'oldPass' => 'required',
	            'newPass' => 'required|same:conPass|min:6',
	            'conPass' => 'required'
	        ]);

	        if($validator->fails())
	        {
	            return redirect()   
	                ->back()
	                ->with('errors', $validator->errors())
	                ->withInput();
	        }

	        $u = User::find($id);   
            $u->password = $request->newPass;
            
            $u->save();

            Session::flash('msg', 'Updated Successfully!');
	    	return redirect()   
	                ->back();
	    }

	    else
	    {
	    	return redirect()   
	                ->back();
	    }

    }

}
