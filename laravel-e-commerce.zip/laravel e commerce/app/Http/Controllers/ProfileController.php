<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;

class ProfileController extends Controller
{
    public function index(Request $request)
    {
    	$id=Session::get('id');

    	$user = DB::table('users')
            ->join('profiles', 'users.userId', '=', 'profiles.userId')
            ->where('users.userId',$id)
            ->first();

    	return view('user.profile')
    	->with('fname', $user->fullName)
    	->with('uname', $user->username)
    	->with('email', $user->email)
    	->with('type', $user->type);
    }
}
