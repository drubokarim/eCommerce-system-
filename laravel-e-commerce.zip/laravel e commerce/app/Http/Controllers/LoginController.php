<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use Session;

class LoginController extends Controller
{
    public function index(Request $request)
    {
    	return view('login');
    }

    public function verify(Request $request)
    {
    	//$un = $request->input('username');
    	
    	/*$user = User::where('username', $request->username)
    		->where('password', $request->password)
    		->first();*/
    	$user = DB::table('users')
    		->where('username', $request->username)
    		->where('password', $request->password)
    		->first();

    	if($user != null)
    	{
            Session::put('id', $user->userId);
            Session::put('lastlog', $user->lastLogin);
            $id = $user->userId;
            $u = User::find($id);

            date_default_timezone_set('Asia/Dhaka');            
            $u->lastLogin = date('Y-m-d H:i:s');
            
            $u->save();
            $request->session()->put('loggedUser', $user);
            
            if($user->type=='Admin')
            {

                return redirect()->route('admin.home');
                //return view('admin.home');

            }
            elseif($user->type=='User')
            {
                return redirect()->route('user.home');
                //return view('user.home');
            }
    		
    	}
    	else
    	{
    		//$request->session()->flash('username', $request->username);
    		//$request->session()->flash('message', 'Invalid username or password');
    		return view('login')
            ->with('message','Invalid username or password');
    		
            
    	}
    }
}
