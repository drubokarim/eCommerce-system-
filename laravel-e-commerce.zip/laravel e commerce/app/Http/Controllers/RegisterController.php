<?php

namespace App\Http\Controllers;

use Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;

class RegisterController extends Controller
{
    public function index(Request $request)
    {
    	return view('register');
    }


    public function store(Request $request)
    {
        

        $validator = Validator::make($request->all(), [

            'username' => 'required|unique:users,userId|unique:profiles,userId',
            'pass' => 'required|same:con_pass|min:6',
            'name' => 'required',
            'email' => 'required|email|unique:profiles,email',
            'dob' => 'required|date'

        ]);

        if($validator->fails())
        {
            return redirect()   
                ->back()
                ->with('errors', $validator->errors())
                ->withInput();
        }

        $user = new User();
        $user->username = $request->username;
        $user->password = $request->pass;
        $user->type = 'User';
        
        date_default_timezone_set('Asia/Dhaka');
        $user->lastLogin= date('Y-m-d H:i:s');
        $user->save();

        $id = DB::table('users')
            ->where('username', $request->username)
            ->first();
        $profiles = new \App\Profile();
        $profiles->userId = $id->userId;
        $profiles->fullName = $request->name;
        $profiles->email = $request->email;
        $profiles->dateOfBirth = $request->dob;
        $profiles->save();
        
        return redirect()->route('login.index')
        ->with('message','Register successful. Please login.');
        //return redirect()->route('account.show', $acc->accId);
    }
}
