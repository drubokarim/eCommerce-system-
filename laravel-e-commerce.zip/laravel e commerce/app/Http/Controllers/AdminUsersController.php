<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;
use App\User;
use Validator;

class AdminUsersController extends Controller
{
    public function index(Request $request)
    {
    	$id=Session::get('id');

    	//$users = User::all();


    	$users = DB::table('users')
            ->join('profiles', 'users.userId', '=', 'profiles.userId')
            ->get();


    	return view('admin.users')
    	->with('users', $users);

    }

    public function edit($id)
    {
    	//$account = Account::find($id);
    	$user = DB::table('users')
    		->join('profiles', 'users.userId', '=', 'profiles.userId')
    		->where('users.userId', $id)
    		->first();

    	return view('admin.edit')
    		->with('fullName', $user->fullName)
    		->with('username', $user->username)
    		->with('type', $user->type);
    }

    public function change(Request $request, $id)
    {
    	//$id=Session::get('id');

	        $u = User::find($id);   
            $u->type = $request->type;
            $u->save();
           

            Session::flash('msg', 'User Type Changed');
	    	return redirect()->route('admin.users');

    }

    public function delete($id)
    {
        //$account = Account::find($id);
        $user = DB::table('users')
            ->join('profiles', 'users.userId', '=', 'profiles.userId')
            ->where('users.userId', $id)
            ->first();

        return view('admin.delete')
            ->with('fullName', $user->fullName)
            ->with('email', $user->email)
            ->with('username', $user->username)
            ->with('lastLogin', $user->lastLogin)
            ->with('type', $user->type);
    }

    public function destroy($id)
    {
            $del= DB::table('users')
            ->where('userId', $id)
            ->delete();
           
            Session::flash('msg', 'user deleted successfully');
            
            return redirect()->route('admin.users');
    }

    


}
