<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;

class HomeController extends Controller
{
    public function index(Request $request)
    {
    	$id=Session::get('id');

    	$user = DB::table('users')
            ->where('userId', $id)
            ->first();

    	return view('user.home')
    	->with('uname', $user->username);
    }
}
