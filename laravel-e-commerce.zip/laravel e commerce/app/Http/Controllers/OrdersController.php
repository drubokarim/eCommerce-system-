<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Validator;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;

class OrdersController extends Controller
{
    public function index(Request $request)
    {
        $orders = DB::table('orders')
        ->join('profiles', 'orders.customerId', '=', 'profiles.userId')
        ->get();
        
         $products = DB::table('products')
        ->get();

        return view('admin.orders')
        ->with('productsInfo', $products)     
        ->with('orders', $orders);
    }
    

    public function userOrder(Request $request)
    {
        $user=$request->session()->get('loggedUser');
        $orders = DB::table('orders')
        ->where('customerId',$user->userId)
        ->get();

        $products = DB::table('products')
        ->get();

        return view('user.order') 
        ->with('productsInfo', $products)    
        ->with('orders', $orders);
    }


    public function place(Request $request)
    {

        $validator = Validator::make($request->all(), [
          'address' => 'required|string|min:15',
          'phone' => 'required|digits:11'
        ]);


        if($validator->fails())
        {
          return redirect()   
              ->back()
              ->with('errors', $validator->errors())
              ->withInput();
        }

        $user=$request->session()->get('loggedUser');
        if($request->session()->has('cart') && !empty($request->session()->get('cart')))
        {
            $cart=$request->session()->get('cart');

            $order = new \App\Order();

        
            $count=1;
            $orderProducts = array();
            foreach ($request->session()->get('cart') as $product_id=>$q2)
            {
                $products = DB::table('products')
                ->where('pId',$product_id)
                ->first();

                $orderProducts[] = array(
                  "pId" => $product_id,
                  "pName" => $products->name,
                  "pPrice" =>  $products->price,
                  "quantity" =>  $q2
                );
                
            }


            $order->products = json_encode($orderProducts);
            $order->customerId = $user->userId;
            
            date_default_timezone_set('Asia/Dhaka');
            $order->orderDate= date('Y-m-d H:i:s');
            $order->address = $request->address;
            $order->phone = $request->phone;
            $order->price = $request->price;
            $order->status = 'Pending';
            $order->save();

           
            $request->session()->forget('cart');
            Session::flash('msg', 'Order has been placed!');

            return redirect()->route('order.userOrder');
        }
        else
        {
            Session::flash('msg', 'Failed to place order!');

            return redirect()->route('cart.index');
        }


    }

    public function changeStatus(Request $request)
    {
        $id=$request->id;
        DB::table('orders')
        ->where('orderId', $id)
        ->update(['status' => $request->status]);

        Session::flash('msg', 'Status Updated!');

        return redirect()->route('orders.index');
    }

}
