<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;
use Validator;
use App\User;
use App\Product;

class ProductsController extends Controller
{
    public function index(Request $request)
    {
        $categories=DB::table('categories')
        ->distinct()
        ->get(['cName']);
        
        $products = DB::table('products')
        ->join('categories', 'products.categoryid', '=', 'categories.id')
        ->get();

        return view('products')     
        ->with('categories', $categories)
        ->with('products', $products);
    }


    public function settings(Request $request)
    {
        $products = DB::table('products')
        ->join('categories', 'products.categoryid', '=', 'categories.id')
        ->get();


        return view('products.products')
        ->with('products', $products);
    }

    public function add(Request $request)
    {
        $categories=DB::table('categories')
        ->get();

        return view('products.add')
        ->with('categories', $categories);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
             'pname'=> 'bail|required|regex:/^[a-z A-z]*[0-9]*[a-z A-z]*+$/|between:2,50|unique:products,name',
             'description'=> 'bail|required|between:10,400',
             'price'=>'bail|required|regex:/^[0-9]+(\.[0-9]{2})?$/',
             'pic'=>'required'
        ]);

        
        if($validator->fails())
        {
            //$request->session()->flash()
            return redirect()   
                ->back()
                ->with('errors', $validator->errors())
                ->withInput();
        }
        

           
        if ($request->hasFile('pic')) {
        $image = $request->file('pic');
        $name = time().'.'.$image->getClientOriginalExtension();
        $destinationPath = public_path('/photos');
        $file="/photos/".$name;
        $image->move($destinationPath, $name);

        $product=new \App\Product();
        $product->name=$request->pname;
        $product->description=$request->description;
        $product->price=$request->price;
        $product->categoryId=$request->category;
        $product->img=$file;
        //$product->img=$path;
        $product->save();

        Session::flash('msg', 'Product Added');
        }
                            
        return redirect()->route('products.settings');
    }

    public function edit(Request $request, $id)
    {
        $user=session('loggedUser');
        $product = DB::table('products')
            ->join('categories', 'products.categoryid', '=', 'categories.id')
            ->where('products.pId', $id)
            ->first();


        $categories = DB::table('categories')
        ->get();

        return view('products.edit')
               ->with('product',$product)
               ->with('categories',$categories)
               ->with('users',$user);
    }

    public function update(Request $request)
    {


        $validator = Validator::make($request->all(), [
             'pname'=> 'bail|required|regex:/^[a-z A-z]*[0-9]*[a-z A-z]*+$/|between:2,50',
             'description'=> 'bail|required',
             'price'=>'bail|required|regex:/^[0-9]+(\.[0-9]{2})?$/',
             'pic'=>'image'
        ]);


        if($validator->fails())
        {
            //$request->session()->flash()
            return redirect()   
                ->back()
                ->with('errors', $validator->errors())
                ->withInput();
        }


        $id=$request->productId;
        $prod = Product::find($id);
        $prod->name=$request->pname;
        $prod->description=$request->description;
        $prod->price=$request->price;
        $prod->categoryId=$request->category;

        if ($request->hasFile('pic')) {
            $image = $request->file('pic');
            $name = time().'.'.$image->getClientOriginalExtension();
            $destinationPath = public_path('/photos');
            $file="/photos/".$name;
            $image->move($destinationPath, $name);
            $prod->img=$file;
        }

       
        $prod->save();

        Session::flash('msg', 'Product Updated');
        return redirect()->route('products.settings');

    }

    public function delete(Request $request, $id)
    {
        $user=session('loggedUser');

        $product=DB::table('products')
                ->join('categories', 'products.categoryId', '=', 'categories.id')
                ->where('products.pId',$id)
                ->first();

        return view('products.delete')
               ->with('users',$user)
               ->with('product',$product);
    }

    public function destroy(Request $request)
    {
        $user=session('loggedUser');
        $id=$request->productId;
        $product=Product::destroy($id);

        Session::flash('msg', 'Product Deleted');
        return redirect()->route('products.settings');
    }




}
