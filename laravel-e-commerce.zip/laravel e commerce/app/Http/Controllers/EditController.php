<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;
use App\Profile;
use Validator;

class EditController extends Controller
{
    public function index(Request $request)
    {
    	$id=Session::get('id');

    	$profile = DB::table('profiles')
            ->where('userId',$id)
            ->first();

    	return view('user.edit')
    	->with('fullName', $profile->fullName)
    	->with('email', $profile->email);
    }


    public function change(Request $request)
    {
    	$id=Session::get('id');
    	$profile = DB::table('profiles')
            ->where('userId',$id)
            ->first();

            $validator = Validator::make($request->all(), [

	            'fullName' => 'required',
	            'email' => 'required|email'
	        ]);

	        if($validator->fails())
	        {
	            return redirect()   
	                ->back()
	                ->with('errors', $validator->errors())
	                ->withInput();
	        }
	    	 
	        $p = Profile::find($id);   

            $p->fullName = $request->fullName;
            
            $p->save();

            Session::flash('msg', 'Updated Successfully!');
	    	return redirect()->route('user.edit');
	    }

    
}
