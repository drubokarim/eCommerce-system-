<?php

namespace App\Http\Controllers;

use Validator;
use Illuminate\Http\Request;
use Session;
use Illuminate\Support\Facades\DB;
use App\User;

class CartController extends Controller
{

    public function index(Request $request)
    {


      if($request->session()->has('cart'))
      {
        $products = DB::table('products')
        ->get();

        $user=$request->session()->get('loggedUser');

        $orders = DB::table('orders')
        ->where('customerId', $user->userId)
        ->orderBy('orderDate', 'desc')
        ->first();

        if($orders!=null)
        {
          return view('cart')
          ->with('orders', $orders)
          ->with('products', $products);
        }

        else
        {
          return view('cart')
          ->with('products', $products);
        }

      }

      else
      {
          return view('cart');
      }

    	
    }

    public function add(Request $request, $item)
    {

      $quantity=1;

  		if($request->session()->has('cart'))
  		{
  			$request->session()->put('cart', array_add($cart = Session::get('cart'), $item, $quantity));
  		}

  		else
  		{
  			
        $request->session()->put('cart', [$item=>$quantity]);
  		}

      Session::flash('msg', 'product added to cart');

      return redirect()->route('products.index');
  		//return view('cart');
    }


    public function updateQuantity(Request $request)
    {

      $validator = Validator::make($request->all(), [
          'quantity' => 'required|integer|min:1'
      ]);

      if($validator->fails())
      {
          return redirect()   
              ->back()
              ->with('errors', $validator->errors())
              ->withInput();
      }


      $id=$request->id;
      $q=$request->quantity;

      $newcart= [];
      foreach ($request->session()->get('cart') as $product_id=>$q2)
      {
        
        if($product_id==$id)
        {
            $q2=$q; 
        }
        $newcart=array_add($newcart,$product_id,$q2);
        
        
      }
      
      $request->session()->put('cart', $newcart);

      return redirect()->route('cart.index');
    }

    public function remove(Request $request, $id)
    {
      
      $newcart= [];
      foreach ($request->session()->get('cart') as $product_id=>$quantity)
      {
        
        if($product_id!=$id)
        {
          $newcart=array_add($newcart,$product_id,$quantity);
        }
      }
      
      $request->session()->put('cart', $newcart);

      return redirect()->route('cart.index');

    }

    
}
?>