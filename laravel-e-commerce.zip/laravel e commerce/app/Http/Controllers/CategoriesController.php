<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;
use Validator;
use App\User;
use App\Category;

class CategoriesController extends Controller
{
    public function index(Request $request)
    {
        $categories=DB::table('categories')
        ->distinct()
        ->get(['cName']);
        
        return view('category')     
        ->with('categories', $categories);
    }


    public function settings(Request $request)
    {
        $categories = DB::table('categories')
        ->get();


        return view('category.categories')
        ->with('categories', $categories);
    }

    public function add(Request $request)
    {
        $categories=DB::table('categories')
        ->get();

        return view('category.add')
        ->with('categories', $categories);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
             'cname'=> 'bail|required|regex:/^[a-z A-z]*[0-9]*[a-z A-z]*+$/|between:2,50'
        ]);

        
        if($validator->fails())
        {
            //$request->session()->flash()
            return redirect()   
                ->back()
                ->with('errors', $validator->errors())
                ->withInput();
        }
        

           
        $Category=new \App\Category();
        $Category->cName=$request->cname;
        //$product->img=$path;
        $Category->save();

        Session::flash('msg', 'Category Added');
        
                            
        return redirect()->route('categories.settings');
    }

    public function edit(Request $request, $id)
    {
        $user=session('loggedUser');
        $category = DB::table('categories')
            ->where('categories.id', $id)
            ->first();

        return view('category.edit')
               ->with('category',$category)
               ->with('users',$user);
    }

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
             'cname'=> 'bail|required|regex:/^[a-z A-z]*[0-9]*[a-z A-z]*+$/|between:2,50'
        ]);


        if($validator->fails())
        {
            //$request->session()->flash()
            return redirect()   
                ->back()
                ->with('errors', $validator->errors())
                ->withInput();
        }


        $id=$request->categoryId;

        $cat = Category::find($id);
        $cat->cName=$request->cname;
       
        $cat->save();

        Session::flash('msg', 'Category Updated');
        return redirect()->route('categories.settings');

    }

    public function delete(Request $request, $id)
    {
        $user=session('loggedUser');

        $category=DB::table('categories')
                ->where('categories.id',$id)
                ->first();

        return view('category.delete')
               ->with('users',$user)
               ->with('category',$category);
    }

    public function destroy(Request $request)
    {
        $user=session('loggedUser');
        $id=$request->categoryId;
        $category=Category::destroy($id);

        Session::flash('msg', 'Category Deleted');
        return redirect()->route('categories.settings');
    }




}
