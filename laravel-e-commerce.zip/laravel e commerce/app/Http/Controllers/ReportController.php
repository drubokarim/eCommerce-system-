<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;
use App\User;
use Validator;

class ReportController extends Controller
{
    public function index(Request $request)
    {	

    	$adminCount = DB::table('users')
            ->where('type','Admin')
            ->count();

    	$userCount = DB::table('users')
            ->where('type','User')
            ->count();


        $users = DB::table('users')
        ->where('type','User')
        ->get();

        $inactivity = array();

        foreach ($users as $user) 
        {
            date_default_timezone_set('Asia/Dhaka');        

            $date1 = strtotime($user->lastLogin);;
            $date2 = strtotime(date('y-m-d'));
            $months = 0;

            while (($date1 = strtotime('+1 MONTH', $date1)) <= $date2)
                $months++;

            $id=$user->userId;

            $inactivity[$user->userId] = $months;

        }  	


        $orders = DB::table('orders')
        ->join('profiles', 'orders.customerId', '=', 'profiles.userId')
        ->orderBy('orders.customerId', 'asc')
        ->get();
        
         $products = DB::table('products')
        ->get();

  
        $max=$totalSpent=0; 
        $bestCustId=$bestCustName=$curId=$bestCustSpent="n/a";

        foreach($orders as $order)
        {
            $prods = json_decode($order->products,true);

            if($curId!=$order->customerId)
            {
               $mostBought=$totalSpent=0;
            }

            foreach($prods as $prod)
            {    
                $mostBought=$prod['quantity']+$mostBought;
            }
            
            $totalSpent=$totalSpent+$order->price;
            $curId=$order->customerId;

            if($mostBought>$max)
            {
                $max=$mostBought; 
                $bestCustId=$order->customerId; 
                $bestCustName=$order->fullName; 
                $bestCustSpent=$totalSpent;
            }
        }
            

    	return view('admin.report')
        ->with('max',$max)
        ->with('bestCustId',$bestCustId)
        ->with('bestCustName',$bestCustName)
        ->with('bestCustSpent',$bestCustSpent)
        ->with('admin', $adminCount)
    	->with('inactivity', $inactivity)
    	->with('user', $userCount)
    	->with('month',$months);

    }


    public function details(Request $request,$cat)
    {

        $users = DB::table('users')
        ->where('type','User')
        ->get();
        
        $inactivity = array();
        
        foreach ($users as $user) 
        {
            date_default_timezone_set('Asia/Dhaka');        

            $date1 = strtotime($user->lastLogin);;
            $date2 = strtotime(date('y-m-d'));
            $months = 0;

            while (($date1 = strtotime('+1 MONTH', $date1)) <= $date2)
                $months++;

            $id=$user->userId;
            
            $inactivity[$id] = $months;
            
        }

        $profiles = DB::table('profiles')
        ->join('users', 'profiles.userId', '=', 'users.userId')
        ->where('users.type','User')
        ->get();

        return view('admin.details')
        ->with('profiles',$profiles)
        ->with('cat',$cat)
        ->with('inactivity',$inactivity);

    }

}
